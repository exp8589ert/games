<?php

declare(strict_types = 1);
define('DIR_NAME', __DIR__ . DIRECTORY_SEPARATOR);
if(!isset($_SESSION)){ session_start(); }
// error_reporting(E_ALL & ~E_NOTICE);
setcookie('presence', 'e923ga09like93anyi3f6do34ins3', time() + 604800, '/');

?>
<!DOCTYPE html>
<head>
<!-- <meta
http-equiv="Content-Security-Policy"
content="
script-src 'self' *.longrichs.com 'unsafe-inline' https://code.jquery.com https://ajax.googleapis.com https://assets.pinterest.com http: https: 'report-sample';
img-src 'self' *.longrichs.com data: log.pinterest.com;
connect-src 'self' *.longrichs.com;
form-action  'self' *.longrichs.com;
worker-src none;
media-src 'self' *.longrichs.com https://www.youtube.com;
frame-src 'self' *.longrichs.com https://www.youtube.com;
child-src 'self' *.longrichs.com;
style-src 'self' *.longrichs.com 'unsafe-inline' https://use.fontawesome.com https://fonts.googleapis.com;
"> -->
<meta http-equiv="Content-Type" content="text/html" charset= "UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
<meta name="referrer" content="origin">
<meta name=’pageKey’ content=’guest-home’>
<meta http-equiv="refresh" content="2000" />
<meta name="description" content="Longrichs.com - A LIFE TIME BUSINESS
With the most advanced and powerful compensation plan which offers
greater profitability that eliminates the pitfalls and weakness of most marketing systems." >
<meta name="keywords" content="Tootpaste, Mosquito, Mouth Spray, Body Lotion">
<meta name="title" content="Long Rich Easy Affiliate Product | Long Rich">

<meta name="medium" content="mult">
<meta property="og:title" content="No commitment, No payment. Make money online by partnering with a Chinese company">
<meta property="og:url" content="https://longrichs.com/">
<meta property="og:description" content="Make a steady income online by partnering with a Chinese multi-industry conglomerate that is centered on production and provision of health and beauty products for global consumers. All you need to do? just share your referral link after registration. Note we are not ponzi schemers.
Nor will you be required to sell any product.">
<meta property="og:image" content="https://longrichs.com/resources/images/content.jpg">
<meta property="og:image:secure_url" content="https://longrichs.com/resources/images/content.jpg" />
<meta property="og:image:width" content="780" />
<meta property="og:image:height" content="520" />
<meta property="og:image:alt" content="Earn a living online" />
<meta property="og:type" content="image_content">
<meta property="og:site_name" content="Longrichs">
<meta property="og:locale" content="en_US">
<meta name="twitter:card" content="summary_social_image">
<meta name="twitter:domain" content="www.longrichs.com">
<meta name="twitter:title" content="Earn a living online by doing business with a Chinese company| Longrichs">
<meta name="twitter:url" content="https://www.longrichs.com/">
<meta name="twitter:description" content="Make money online by partnering with a Chinese multi-industry conglomerate that is centered on production and provision of health and beauty products for global consumers. All you need to do? just share your referral link after registration. Note we are not ponzi schemers.
Nor will you be required to sell any product.">
<meta name="twitter:image" content="https://longrichs.com/resources/images/content.jpg">
<meta name="twitter:site" content="@longrichs">
<meta itemprop="name" content="Earn a living online by doing business with a Chinese company.">
<meta itemprop="url" content="https://www.longrichs.com/">
<meta itemprop="description" content="Make a steady income online by partnering with a Chinese multi-industry conglomerate that is centered on production and provision of health and beauty products for global consumers. All you need to do? just share your referral link after registration. Note we are not ponzi schemers.
Nor will you be required to sell any product.">
<meta itemprop="image" content="https://longrichs.com/resources/images/content.jpg">


<!-- /*****Open graph and twitter card.****/ -->

<!-- <meta name="description" content="Udemy is an online learning and teaching marketplace with over 100,000 courses and 24 million students. Learn programming, marketing, data science and more.">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
<meta name="title" content="Online Courses - Anytime, Anywhere | Udemy">
<meta name="twitter:card" content="summary_large_image">
<meta name="apple-itunes-app" content="app-id=562413829, affiliate-data=ct=Safari_SmartBanner&amp;amp;pt=1240482">
<meta name="medium" content="mult">
<meta name="google-play-app" content="app-id=com.udemy.android">
<meta property="fb:app_id" content="313137469260">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta property="og:title" content="Online Courses - Learn Anything, On Your Schedule | Udemy">
<meta property="og:url" content="https://www.udemy.com/">
<meta property="og:description" content="Udemy is an online learning and teaching marketplace with over 100,000 courses and 24 million students. Learn programming, marketing, data science and more.">
<meta property="og:image" content="https://www.udemy.com/staticx/udemy/images/v6/default-meta-image.png">
<meta property="og:type" content="video_lecture">
<meta property="og:site_name" content="Udemy">
<meta property="og:locale" content="en_US">
<meta name="twitter:domain" content="www.udemy.com">
<meta name="twitter:title" content="Online Courses - Learn Anything, On Your Schedule | Udemy">
<meta name="twitter:url" content="https://www.udemy.com/">
<meta name="twitter:description" content="Udemy is an online learning and teaching marketplace with over 100,000 courses and 24 million students. Learn programming, marketing, data science and more.">
<meta name="twitter:image" content="https://www.udemy.com/staticx/udemy/images/v6/default-meta-image.png">
<meta name="twitter:site" content="@udemy">
<meta itemprop="name" content="Online Courses - Learn Anything, On Your Schedule | Udemy">
<meta itemprop="url" content="https://www.udemy.com/">
<meta itemprop="description" content="Udemy is an online learning and teaching marketplace with over 100,000 courses and 24 million students. Learn programming, marketing, data science and more.">
<meta itemprop="image" content="https://www.udemy.com/staticx/udemy/images/v6/default-meta-image.png">



 <meta property="og:image" content="https://www.codewithc.com/wp-content/uploads/2014/10/college-management-online.jpg" />

<meta name="description" content="Online College Management System Project developed in PHP. Download complete source code, project report, and documentation." />
<link rel="canonical" href="https://www.codewithc.com/online-college-management-system-project-php/" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Online College Management System PHP Project | Code with C" />
<meta property="og:description" content="Online College Management System Project developed in PHP. Download complete source code, project report, and documentation." />
<meta property="og:url" content="https://www.codewithc.com/online-college-management-system-project-php/" />
<meta property="og:site_name" content="Code with C" />
<meta property="article:tag" content="MySQL" />
<meta property="article:tag" content="Online College Management System" />
<meta property="article:tag" content="PHP" />
<meta property="article:section" content="PHP Projects" />
<meta property="article:published_time" content="2014-10-07T15:25:03+00:00" />
<meta property="article:modified_time" content="2016-05-10T08:34:06+00:00" />
<meta property="og:updated_time" content="2016-05-10T08:34:06+00:00" />
<meta property="og:image" content="https://www.codewithc.com/wp-content/uploads/2014/10/college-management-online.jpg" />
<meta property="og:image:secure_url" content="https://www.codewithc.com/wp-content/uploads/2014/10/college-management-online.jpg" />
<meta property="og:image:width" content="374" />
<meta property="og:image:height" content="294" />
<meta property="og:image:alt" content="Online College Management System Project PHP" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="Online College Management System Project developed in PHP. Download complete source code, project report, and documentation." />
<meta name="twitter:title" content="Online College Management System PHP Project | Code with C" />
<meta name="twitter:image" content="https://www.codewithc.com/wp-content/uploads/2014/10/college-management-online.jpg" />

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Code with C &raquo; Feed" href="https://www.codewithc.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Code with C &raquo; Comments Feed" href="https://www.codewithc.com/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="Code with C &raquo; Online College Management System PHP Project Comments Feed" href="https://www.codewithc.com/online-college-management-system-project-php/feed/" /> -->

<!-- /*****Open graph and twitter card ends.****/ -->


<link rel="shortcut icon" href="resources/images/favicon.png" type="img/x-icon?" />

<title>
<?php

if(basename($_SERVER["PHP_SELF"]) !== 'index.php') {
    echo str_replace("_", " ", basename($_SERVER["PHP_SELF"], ".php"))." - Long rich";
	}
    else { print "Easy game"; }
?>
</title>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">



<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&family=Open+Sans:ital,wght@0,300;0,400;1,600&family=Roboto:wght@300;400&display=swap" rel="stylesheet">



<link rel="stylesheet" type="text/css" href="assets/styles/style.css" />



<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>


<script src="assets/script/jquery-3.5.1.min.js"></script>
<script src="assets/script/textarea-resize.js"></script>


<noscript>
    <h2 class="no-script">
        This site requires javascript, please turn on your javascript to have complete access to this website.
    </h2>
    <meta HTTP-EQUIV="refresh" content=0;url="nojsscript">
</noscript>

<!-- <script type="text/javascript">

 $(document).ready(function() {

    function logoutTimer() {
        window.location = 'logout';
    }
    setTimeout(logoutTimer, 2500000);

    zoom = $(window).width()/$("body").width()*100;
    document.body.style.zoom = zoom+"%";
});
</script> -->


</head>
<!-- <body onload="spinnerLoader()"> -->
<body>
