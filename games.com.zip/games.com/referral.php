<?php require 'header.php'; ?>
<?php require 'main.php'; ?>

<main class="referral front">
	
	<div class="wrapper">
		<aside class="left">
			<h3>
				Invite Friends. <br />
				Earn Crypto Together <br />
				<span>Earn up to <span class="brighter">40% commission</span> every time your friends plays game on p4pgames.</span>

				<br />

				<div class="lower">
					<div class="invite">Invite now</div>
					<div class="rules">Referral rules</div>
				</div>

			</h3>

			
		</aside>

		<aside class="right">
			<div class="enclosed">
				xxxxxx
			</div>
		</aside>
	</div>

	<menu>
		<ul>
			<a href="#"><li class="active">Overview</li></a>
			<a href="#"><li>xxxx</li></a>
			<a href="#"><li>Referral List</li></a>
			<a href="#"><li>History</li></a>
			<a href="#">
				<li class="invite">
					<div class="invite">Invite now</div>
				</li>
			</a>
		</ul>
	</menu>

</main>




<section class="account referral">


<div class="inner">
	Referral...
</div>



<footer class="mini footer bottom">
	<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>
</footer>


</section>

<script src="assets/script/script.js"></script>