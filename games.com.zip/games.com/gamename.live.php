<?php require 'header.php'; ?>
<?php #equire 'main.php'; ?>



<section class="account body overview" id="active">


<div class="active nav">

	<ul>
		<li class="live target">

			<i class="fab fa-squarespace"></i> Menu

			<ul class="tray livebox">
				<li>Player Protection</li>
				<li>My Account</li>
				<li>sdsdcsd</li>
				<li>sdsdcsd</li>
				<li>Game Help</li>
				<li>Contact Support</li>
			</ul>
			
		</li>

		<li>
			<label>Wallet</label>
			<label class="amount">$250.12</label>
		</li>

		<li> 
			<label class="deposit">Deposit &nbsp;<i class="fas fa-donate"></i></label>
		</li>

		<li> 
			<label>Stake</label>
			<label class="amount">$50.12</label>
		</li>

		<li> 
			<label>To Win</label>
			<label class="amount">$450.12</label>
		</li>

		<li class="space out"></li>

		<li class="translate target">
			<div class="target">
				<i class="fas fa-globe-europe target"></i> &nbsp;English

				<div class="list target langbox">
					Spannish...
				</div>

			</div>
		</li>

		<li class="volume"><i class="fas fa-volume-up vol"></i></li>
		<li>Exit Game <i class="far fa-times-circle exit"></i></li>
	</ul>
 </div>



<div class="inner">




<div class="wrapper">
	<!-- wrapper...
	<br />
	<br />

	In-Play...Ended...Live...
	Spin Trigger...30 Times...Min Wager...300 in BTC...
	Contest Duration...5 hours...Estimated Prize...2500 BTC...
	Loading...===...Menu top... Left...Paytable...Promotions..
	Help & Contact Us.. -->


</div>


</div>







<footer class="footer mini bottom">

<!-- &nbsp;&nbsp; -->
<label>
Gambling can be addictive. Please play responsibly.
</label>

<label class="adult"></label>

<label>
© 2014 - 2021 p4pgames.com. All rights reserved.</label>






</footer>


</section>

<div id="transparent" class="overview opacity"></div>
<script src="assets/script/script.js"></script>