<?php require 'header.php'; ?>
<?php require 'main.php'; ?>


<section class="account payments">


<main class="inner">

	<div class="box">
		
	<div class="encompass">
		
	
	

<div class="upper">

		<div class="container">

		<menu class="actions">

			<div class="avail-bal">
				<label class="av">
					Available Balance: 
					<span class="value">750.00 $ </span>
				</label>

				<label>
					Total on hold:
					<span class="value">00.00 $ </span>
				</label>
				
			</div>

			<ul>
				<li>
					<label for="statement">
						<input type="radio" name="action" id="statement" checked="checked">
						<span>Statement</span>
					</label>
				</li>

				<li>
					<label for="deposit">
						<input type="radio" name="action" id="deposit">
						<span>Deposit</span>
					</label>
				</li>

				<li>
					<label for="withdraw">
						<input type="radio" name="action" id="withdraw">
						<span>Withdraw</span>
					</label>
				</li>

				<li>
					<label for="exchange">
						<input type="radio" name="action" id="exchange">
						<span>Exchange</span>
					</label>
				</li>

			</ul>			

		</menu>

		<div class="settings">
			<div class="auth">

				<div class="steps">
						<hr />
					<span class="one"><i class="fas fa-check done"></i></span>
					<span class="two">2</span>
					<span class="three">3</span>
				</div>

		<div class="details">
			<label>Register Account.</label>

			<label>Activate two factor authentication <br />
				<span class="verify">Verify</span>
			</label>

			<label>Deposit Funds</label>
		</div>

				
			</div>

			<div class="img"></div>
		</div>

		<div class="effect">



			<aside class="left">

				<div class="title"></div>

				<ul class="wallet">

					<li class="hide-others">
						BTC <br />
						<span class="bal">฿
							<span class="value">0.13</span>
						</span>
					</li>

					<li class="hide-others">ETH
					<br />
						<span class="bal">Ξ
							<span class="value">0.345</span>
						</span>
					</li>

					<li class="hide-others">USD
					<br />
						<span class="bal">$
							<span class="value">4,571.09</span>
						</span>
					</li>

					<li class="hide-others">EUR
					<br />
						<span class="bal">€
							<span class="value">59.17</span>
						</span>
					</li>

					<li class="hide-others">GBP
					<br />
						<span class="bal">£
							<span class="value">124.00</span>
						</span>
					</li>


				</ul>
			</aside>

		
<aside class="right">




	<div class="statement box-d show">
	
		
	<h5>
		Here is a summary of your account 

		<label class="enclose">
			<span class="settings-icon"></span>
		</label>

	</h5>

 	<div class="type wrapper">

	<div class="main">
		
	

	<aside class="main-bal">
		<label>Main Balance</label>
		<label>480.06 <sup>$</sup></label>
		<label>(After earning $120 last 3 Months)</label>
	</aside>

	<aside class="bonus-bal">
		<label>Bonus Balance</label>
		<label>375.00 <sup>$</sup></label>
		<label>(After earning $120 last 3 Months)</label>
	</aside>

	<aside class="main-wall">
		<label>Main Wallet</label>
		<label>1,280.06 <sup>$</sup></label>
		<label>(After earning $350 last 3 Months)</label>
	</aside>

	<aside class="ref-bonus">
		<label>Referral Bonus</label>
		<label>475.00 <sup>$</sup></label>
		<label>(After earning $75 last 3 Months)</label>
	</aside>

	</div>

	<div class="others">
		 <label>Internal transfer <span>$ 175.20</span></label>
		 <label>External transfer <span>$ 275.20</span></label>
	</div>

</div>

<div class="bottom">
	




<div class="switch-box">
	<span class="state off">Off</span>
	<label class="switch">
		<input type="checkbox" checked="checked">
		<span class="slider round"></span>
	</label>
	<span class="state on">On</span>
</div>
		<p>
				Welcome to Binance
				Just a few more steps and you’re good to go!
				...
				Deposit Funds...
				Add cash or crypto funds to your wallet and start trading right away....
				Enter amount:
				<input type="number" name="" placeholder="$10 or more">Main wallet: ...				Min deposit: $10 Processing: Instant Fee: 0% [?]
				<button>Proceed</button>
				</p>


</div>
			


</div>

<div class="deposit box-d">


<label class="act-title">Deposit Funds <span class="show-m">
<i class="fab fa-hornbill"></i> Show methods</span>
</label>

<div class="deposit-wrap">

<ol class="instruction">
<li>Select account and enter amount to deposit</li>
<li>
	Choose payment method <br/> <br/> 
	Enter Credit Card details or Send funds to given cryto address using your desktop or mobile cryptowallet. Funds will be deposited approx. in 30 mins - 1 hour. <br /> <br/> 
	If you have further questions, please contact out support team. g
</li>
<li>
	Additional Information
</li>

<li>
	<div class="add-info">
		<label>Amount to pay <span>0.0365 BTC</span></label>
		<label>Amount to deposit <span>0.0365 BTC</span></label>
		<label>Fee <span>0.00 0BTC</span></label>
		<label>Percent fee <span>0%</span></label>
		<label>gFixed fee <span>0.0002 BTC</span></label>
	</div>
</li>




</ol>


<div class="inputs">


<form>
	
<div class="up">

	<label>
		<span>To account</span> <br />
		<select class="wallets">

			<option selected="selected">Select account</option>
			<option value="btc">BTC <span>0.00129</span></option>
			<option value="eth">ETH <span>0.00762</span></option>
			<option value="usd">USD <span>685.07</span></option>
			<option value="eur">EUR <span>468.75</span></option>
			<option value="gbp">GBP <span>560.29</span></option>
			
		</select>
	</label>


		<label for="amount">
			<span>Enter amount to deposit</span> <br />
			<input type="number" name="dep-amount" id="amount" placeholder="Enter amount">
		</label>
</div>


<div class="methods">

	<ul class="methlist">
		<li class="credit">
			<label>Credit Cards</label>
		</li>
		<li class="paypal">
			<label>Paypal</label>
		</li>
		<li class="stripe">
			<label>Stripe</label>
		</li>
		<li class="amazon-pay">
			<label>Amazon Pay</label>
		</li>
		<li class="alipay">
			<label>Alipay</label>
		</li>
		<li class="google-pay">
			<label>Google Pay</label>
		</li>
		<li class="bitcoin">
			<label>Bitcoin wallet</label>
		</li>

		<li class="skrill">
			<label>Skrill</label>
		</li>

		<li class="ethereum">
			<label>
				Ethereum wallet
			</label>
		</li>
	</ul>
</div>



<div class="middle bitcoin">
	BTC middle
</div>

<div class="middle ethereum">
	ETH middle
</div>



<div class="middle c-cards">
	

	<ul class="gateway-img">
		<li class="visa"></li>
		<li class="master"></li>
		<li class="amex"></li>
		<li class="jcb"></li>
		<li class="discover"></li>
	</ul>



<div class="collect">

<label class="bill">Billing Details</label>

<br />

<ul>
<li>
	<label for="firstname">
	<span>Firstname</span> <br />
	<input type="text" id="firstname" name="" autofocus placeholder="Enter First" maxlength="50">
	</label>

	<label for="surname">
	<span>Surname</span> <br />
	<input type="text" id="surname" name="" autofocus placeholder="Enter Surname" maxlength="50">
	</label>
</li>

<li>
	
	<label for="email">
	<span>Email address</span> <br />
	<input type="email" id="email" name="" autofocus placeholder="Enter email address" maxlength="50">
	</label>

	<label for="country">
	<span>Country</span> <br />
	<select id="country">
			<option>Country</option>
			<option>Nigeria</option>
			<option>Biafra</option>
			<option>United States</option>
			<option>Ghana</option>
	</select>
	</label>
</li>

<li>
	<label for="state">
		<span>State/County</span> <br />
		<input type="text" id="state" name="" placeholder="Enter State/County" maxlength="50">
	</label>

	<label for="postal">
		<span>Zip/postal code</span> <br />
		<input type="number" id="postal" name="" placeholder="Zip/postal code" maxlength="50">
	</label>

</li>

<li class="credit-card">

	<label for="card-number">
		<span>Card number</span> <br />
		<input type="number" id="card-number" name="" placeholder="Enter card number" maxlength="18">
	</label>

	
	<div class="three">

		<label for="month">
		<span>
			Expiration date
		</span>

			<select id="month">
				<option>Month</option>
				<option>Jan</option>
				<option>Feb</option>
				<option>Mar</option>
				<option>Apr</option>
				<option>May</option>
				<option>Jun</option>
				<option>Jul</option>
				<option>Aug</option>
				<option>Sep</option>
				<option>Oct</option>
				<option>Nov</option>
				<option>Dec</option>
			</select>
		</label>

		<label for="year">&emsp;
			<select id="year">
				<option>Year</option>
				<option>2035</option>
				<option>2034</option>
				<option>2033</option>
				<option>2032</option>
				<option>2031</option>
				<option>2030</option>
				<option>2029</option>
				<option>2028</option>
				<option>2027</option>
				<option>2026</option>
				<option>2025</option>
				<option>2024</option>
				<option>2023</option>
				<option>2022</option>
				<option>2021</option>
				<option>2020</option>
			</select>
		</label>

		<label for="security">
			<span>Security code</span> <br />
			<input type="number" id="security" name="" placeholder="Three digits" max="3" maxlength="3" onKeyPress="if(this.value.length === 3) return false;">
		</label>
	</div>

</li>



</ul>


<br />

<h5>By clicking the deposit funds, you agree to the 
<a href="#">Terms & Conditions</a>
</h5>

<br />



<button type="submit" class="proceed">Proceed with payment</button>

</div> <!-- Collect ends. -->



</div> <!-- Middle ends -->


	<div class="down">
		<ul class="down">
			<li>Send BTC to your p4pgames account using the given crypto address or scan QR-code with your mobile Bitcoin Wallet.
			</li>
			<li>
				Crypto address
				<span class="addr">
					sdjckksjc35132dc1sdcsdcjchksavnsdf
				</span>
			</li>
		</ul>

		 <img src="/games.com/resources/picture/sample.png" class="btc-barcode">

	</div>



</form>



</div>
		


</div>	
	
		

</div>



<div class="withdraw box-d">

<label class="act-title">
Funds withdrawal
</label>


Secret Code


<div class="withdraw-wrap">

<ul class="instruction">
	<li>dscscsdcsd</li>
	<li>dscscsdcsd</li>
	<li>dscscsdcsd</li>
</ul>

<div class="inputs"> </div>

</div>


<div class="switch-box">
	<span class="state off">Off</span>
	<label class="switch">
		<input type="checkbox" checked="checked">
		<span class="slider round"></span>
	</label>
	<span class="state on">On</span>
</div>

				<!-- <table class="withdraw">
				<thead>
					<th>Date & Time</th>
					<th>Amount</th>
					<th>Type</th>
					<th>Status</th>
				</thead>
				<tbody>
					<tr>
						<td>04-12-2021 08:35</td>
						<td>0.0368</td>
						<td>Withdrawal</td>
						<td>In progress</td>
					</tr>

				</tbody>
			</table> -->


</div>

<div class="exchange box-d">


	<div class="options">

		<label class="rate">
			1 BTC/USD exchange rate: 
			<span>$48,605.00</span>
		</label>


<div class="select-wrap">
<label>Choose currency</label>
<select class="currency">
	<option selected="selected" data-pair="" value="">BTC/USD</option>
	<option data-pair="" value="">BTC/EUR</option>
	<option data-pair="" value="">BTC/GBP</option>

	<option data-pair="" value="">ETH/USD</option>
	<option data-pair="" value="">ETH/EUR</option>
	<option data-pair="" value="">ETH/GBP</option>

	<option data-pair="" value="">USD/EUR</option>
	<option data-pair="" value="">USD/GBP</option>
</select>
</div>

</div>


	<?php #require'exchange.php'; ?>


<div class="exchange-box">

<div class="btc-usd trade show">
<div class="c-img bit-usd"></div>



<div class="live-rate xxcc">
	<i class="far fa-chart-bar"></i>
BTC/USD
Currency rates.
</div>
<div class="trade-box xxcc">
<aside>

<form>
<ul>
<li class="aa">
<span class="title expl">Sell Bitcoin</span>
<span class="normal">(Min: 0.0002 | Max: 2 btc)</span>
</li>



<li class="bb">
<label for="bitcoin-amt">
<input type="number" id="bitcoin-amt" focus="focus" name="bitcoin-amt" placeholder="Enter amount" onKeyPress="if(this.value.length === 6) return false;">
</label>
<label>
<span class="title picked">USD</span>
<span>BTC</span>
</label>
</li>

<li>
<span class="title">Bitcoin Balance</span>
<span class="value">0.0095</span>
</li>

<li>
<span class="title normal">Fee, BTC</span>
<span class="value">0.00009 </span>
</li>

<li>
<span class="title">Pay BTC</span>
<span class="value">0.00759</span>
</li>

<li>
<span class="title">Get USD</span>
<span class="value">650.00 $</span>
</li>

<li class="last">
<button class="sell btn" type="submit">
Sell Bitcoin 
<i class="far fa-dot-circle"></i>
</button>
</li>

</ul>
</form>
</aside>

<aside>
<form>
<ul>

<li class="aa">
<span class="title expl buy">Buy Bitcoin</span>
<span class="normal">(Min: 0.0002 | Max: 2 btc)</span>
</li>



<li class="bb">
<label for="bitcoin-amt">
<input type="number" id="bitcoin-amt" focus="focus" name="bitcoin-amt" placeholder="Enter amount" onKeyPress="if(this.value.length === 6) return false;">
</label>
<label>
<span class="title">USD</span>
<span>BTC</span>
</label>
</li>

<li>
<span class="title">USD Balance</span>
<span class="value">0.0095</span>
</li>

<li>
<span class="title normal">Fee, USD</span>
<span class="value">4.50 </span>
</li>

<li>
<span class="title">Pay USD</span>
<span class="value">650.00 $</span>
</li>

<li>
<span class="title">Get BTC</span>
<span class="value">0.00759</span>
</li>


<li class="last">
<button class="buy btn" type="submit">
Buy Bitcoin 
<i class="far fa-dot-circle"></i>
</button>
</li>

</ul>
</form>
</aside>

</div>
</div>

</div>










</div>







<div class="wallet-box btc">
	
<div class="crypto">

<div class="opera">

<img src="/games.com/resources/vector/bitcoin-2.svg">

<label class="title">Bitcoin Balance: 
<span class="value">0.0519</span>
</label>

<label>

Bitcoin Transactions (<i class="fab fa-bitcoin"></i>)
</label>



</div>



<div class="instruc">
<div class="info">
<span>
Scan barcode to deposit bitcoin into your account.
<br />
BTC Address:
<span class="btc-add">
sdjckksjc35132dc1sdcsdcjchksavnsdf
</span> 
</span>
</div>

<img src="/games.com/resources/picture/sample.png" class="barcode">


</div>



</div>






<div class="table-wrap">


<table class="btc">
<thead>
<th>Date & Time</th>
<th>Amount</th>
<th>Type</th>
<th>Status</th>
</thead>
<tbody>
<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Withdrawal</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Commissions</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

</tbody>
</table>

</div>

</div>




<div class="wallet-box eth">
	
	<div class="crypto">

<div class="opera">

<img src="/games.com/resources/vector/ethereum.svg">

<label class="title">Ethereum Balance: 
<span class="value">0.0519</span>
</label>

<label>

Ethereum Transactions (<i class="fab fa-ethereum"></i>)
</label>



</div>



<div class="instruc">
<div class="info">
<span>
Scan barcode to deposit ethereum into your account.
<br />
ETH Address:
<span class="btc-add">
xksdsjhsolfoqcksjc32dc1csdcqw12wlo5ch4556s
</span> 
</span>
</div>

<img src="/games.com/resources/picture/sample.png" class="barcode">

<!--  -->
</div>






</div>

<div class="table-wrap">


<table class="btc">
<thead>
<th>Date & Time</th>
<th>Amount</th>
<th>Type</th>
<th>Status</th>
</thead>
<tbody>
<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Withdrawal</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Commissions</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

</tbody>
</table>

</div>

</div>





<div class="wallet-box usd">
	
<div class="crypto">

<div class="opera">

<img src="/games.com/resources/vector/dollar.svg" class="c">

<label class="title">USD Balance: 
<span class="value">751.25</span>
</label>

<label>

USD Transactions (<i class="fas fa-dollar-sign"></i>)
</label>



</div>



<div class="instruc">
<div class="info">
<span>
Scan barcode to deposit bitcoin into your account.
<br />
BTC Address:
<span class="btc-add">
sdjckksjc35132dc1sdcsdcjchksavnsdf
</span> 
</span>
</div>

<img src="/games.com/resources/picture/sample.png" class="barcode">
</div>




</div>

<div class="table-wrap">


<table class="btc">
<thead>
<th>Date & Time</th>
<th>Amount</th>
<th>Type</th>
<th>Status</th>
</thead>
<tbody>
<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Withdrawal</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Commissions</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

</tbody>
</table>

</div>

</div>




<div class="wallet-box eur">

<div class="crypto">

<div class="opera">

<img src="/games.com/resources/vector/euro.svg" class="c">

<label class="title">EUR Balance: 
<span class="value">0.0519</span>
</label>

<label>

EUR Transactions (<i class="fas fa-euro-sign"></i>)
</label>



</div>



<div class="instruc">
<div class="info">
<span>
Scan barcode to deposit bitcoin into your account.
<br />
BTC Address:
<span class="btc-add">
sdjckksjc35132dc1sdcsdcjchksavnsdf
</span> 
</span>
</div>

<img src="/games.com/resources/picture/sample.png" class="barcode">

</div>




</div>

<div class="table-wrap">


<table class="btc">
<thead>
<th>Date & Time</th>
<th>Amount</th>
<th>Type</th>
<th>Status</th>
</thead>
<tbody>
<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Withdrawal</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Commissions</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

</tbody>
</table>

</div>
</div>




<div class="wallet-box gbp">
	<div class="crypto">

<div class="opera">

<img src="/games.com/resources/vector/pounds.svg" class="c">

<label class="title">GBP Balance: 
<span class="value">0.0519</span>
</label>

<label>

GBP Transactions (<i class="fas fa-pound-sign"></i>)
</label>



</div>



<div class="instruc">
<div class="info">
<span>
Scan barcode to deposit bitcoin into your account.
<br />
BTC Address:
<span class="btc-add">
sdjckksjc35132dc1sdcsdcjchksavnsdf
</span> 
</span>
</div>

<img src="/games.com/resources/picture/sample.png" class="barcode">
</div>






</div>

<div class="table-wrap">


<table class="btc">
<thead>
<th>Date & Time</th>
<th>Amount</th>
<th>Type</th>
<th>Status</th>
</thead>
<tbody>
<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Withdrawal</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Commissions</td>
<td>In progress</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Completed</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Pending</td>
</tr>	

<tr>
<td>04-12-2021 08:35</td>
<td>0.0368</td>
<td>Deposit</td>
<td>Failed</td>
</tr>

</tbody>
</table>

</div>
</div>




</aside>


		</div>



			<div class="trust">
				You can trust p4pgames with your card details: Betfair protects sensitive customer data using SSL encryption during transmission and uses 128-bit SSL Verisign Class 3 Certificates
			</div>
		</div>

		<ul class="security-assurance">
			<li class="approval"></li>
			<li class="norton"></li>
			<li class="master"></li>
			<li class="visa"></li>
		</ul>
	</div>

	<br />

	<div class="lower">
		<label>Top payment question&nbsp; 
			<i class="fas fa-question"></i>
		</label>


		<ul class="ques">
			<li class="active">How long will a withdrawal take to clear from my account?</li>
			<div class="content show">
				<p>
					&emsp; Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
				</p>
			</div>

			<li>Why do card withdrawals take 2-5 days when card deposits are immediate?</li>
			<div class="content">
				<p>
					&emsp; Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
				</p>
			</div>

			<li>Why can't I always choose how I withdraw my funds?</li>
			<div class="content">
				<p>
					&emsp; Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
				</p>
			</div>

			<li>Withdrawing & Depositing Funds</li>
			<div class="content">
				<p>
					&emsp; Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
				</p>
			</div>

			<li>How are the transaction charges calculated?</li>
			<div class="content">
				<p>
					&emsp; Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.
				</p>
			</div>


		</ul>


	</div>
	


	</div>

	<div class="payment-footer">
		<ul>
			<li><a href="#">Statement</a></li>
			<li><a href="#">Affiliate</a></li>
			<li><a href="#">Developers</a></li>
			<li><a href="#">Support</a></li>
			<li><a href="#">Legacy Policy</a></li>
			<li><a href="#">Copyright</a></li>
		</ul>
	</div>
	
</div>


</main>


<!-- <div class="transp account"></div> -->

<footer class="mini footer bottom">
	<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>
</footer>


</section>

<script src="assets/script/script.js"></script>