<?php require 'header.php'; ?>


<style type="text/css">
	
.account.deposit {
width: 100%;
min-height: 100%;
position: absolute;
display: flex;
flex-wrap: wrap;
justify-content: center;
background: #f1f2f6;
/*border: 0.2em solid red;*/
}
.account.deposit .logo-block {
width: 100%;
height: 2.8em;
/*margin: 0 auto;*/
display: flex;
align-items: center;
justify-content: space-between;

/*border: 0.1em solid red;*/
}

.account.deposit .logo-block label {
border: 0.2em solid red;
margin-left: 2em;
}


.account.deposit .logo-block .language {
font-size: 0.83em;
/*margin-top: 8em;*/
height: 80%;
width: 8%;
display: flex;
cursor: pointer;
align-items: center;
justify-content: center;
color: #4b4b50;
text-shadow: 0 0 0.1em #dadce2;
/*border: 0.13em solid red;*/
}
.account.deposit .logo-block .langbox {
width: 17em;
height: 22em;
top: 3em;
right: 2em;

padding: 0.9em;
cursor: default;
background: #fff;
position: absolute;
z-index: 5;
border: 0.11em solid #bbbdce;
display: none;
}
.account.deposit .language:hover .langbox {
display: block;
}
/*.account.deposit .logo-block .langbox.show {
display: block;
}*/


.account.deposit .inner {
width: 61em;
min-height: 45em;
height: auto;
max-height: 60em;
margin: 4% auto 10em;
background: #fff;
display: flex;
border-radius: 0.1em;
align-content: center;
box-shadow: 0 0 0.08em 0.01em #a2a2aa;


/*border: 0.2em solid violet;*/
}


.account.deposit .triangle {
width: 0;
height: 0;
z-index: 1;
position: absolute;
border-top: 18em solid #197ce0;
border-right: 18em solid transparent;
}

.account.deposit .wrapper {
width: 53em;
height: 38em;
height: auto;
max-height: 54em;
z-index: 4;
margin: 3em auto;
position: relative;
padding: 1em;
background: #ebecf2;

display: flex;
flex-wrap: wrap;
align-content: space-between;

/*border: 0.08em solid blue;*/
}

/*
.account.deposit .upper {
width: 100%;
height: 7%;
background: #fff;
padding: 0.5em 1.7em;
display: flex;
justify-content: space-between;

border: 0.1em solid red;
}*/

.account.deposit .lower {
padding: 1.3em 1em 1.3em;
width: 100%;
min-height: 90%;
height: auto;
min-height: 95%;
background: #fff;
display: flex;
flex-wrap: wrap;
justify-content: space-between;

/*border: 0.1em solid green;*/
}

.account.deposit .lower .title {
width: 98%;
margin: 0 auto;
font-size: 0.99em;
display: flex;
justify-content: space-between;
/*border: 0.1em solid red;*/
}

.account.deposit .lower .title label {
font-size: 0.85em;
color: #3e73d8;
font-weight: bold;
}

.account.deposit .lower .progress {
width: 42%;
display: flex;
align-items: center;
justify-content: space-around;
font-size: 0.82em;
color: #92939a;
font-family: 'Roboto', sans-serif;
text-shadow: 0 0 0.1em #dadce2;

-webkit-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
/*border: 0.1em solid red;*/
}

/*.account.deposit .lower .progress.active {
color: #5d5d60;
}
.account.deposit .lower .progress.active label {

}*/

.account.deposit .lower .progress label {
border-radius: 50%;
width: 1.83em;
height: 1.83em;
font-weight: bold;
color: #81828b;
font-size: 0.79em;
display: inherit;
align-items: inherit;
justify-content: center;
background: #e8e8ed;
border: 0.2em solid #a8a9af;
}

.account.deposit .lower .progress .one {
color: #ebecef;
font-size: 0.75em;
background: #2db92d;
border: 0.21em solid #2db92d;
}
.account.deposit .lower .progress .two {
color: #2db92d;
background: #f8f8f8;
border: 0.21em solid #2db92d;
}

.account.deposit .lower .progress hr {
width: 2.8em;
background: #dadce3;
border: 0.09em solid #dadce3;
}

.account.deposit .lower .deposit label {
color: #373740;
font-size: 0.82em;
text-shadow: 0 0 0.1em #dadce2;
}

.account.deposit .lower .left {
width: 47%;
height: 100%;
padding: 0 0.4em;
/*border: 0.1em solid green;*/
}

.account.deposit .lower fieldset {
border: none !important;
padding: 0 0 2em;
height: auto;

/*border: 0.1em solid green;*/
/*max-height: 60em;*/
}




.account.deposit .lower li {
margin: 0.3em 0;
}

.account.deposit li.double {
display: flex;
justify-content: space-between;
}

.account.deposit .state,
.account.deposit .email {
width: 56%;
}
.account.deposit .postal,
.account.deposit .country {
width: 40%;
}





.account.deposit .lower input,
.account.deposit .lower select {
background: #fff;
padding: 0.35em 0.6em;
width: 100%;
height: 2.2em;
color: #46464e;
font-size: 0.89em;
border-radius: 0.1em;
border: 0.08em solid #a8abb4;
box-shadow: 0 0 0.1em 0 #dadce2;
}
.account.deposit .lower input::placeholder {
font-size: 0.88em;
}

.account.deposit .lower input:focus, 
.account.deposit .lower select:focus {
border: 0.08em solid #4299f0;
box-shadow: 0 0 0.15em 0 #4299f0;
}


.account.deposit .lower select {
padding: 0.35em;
}
.account.deposit .lower select option {
font-size: 0.99em;
}

.account.deposit .lower label.method {
font-size: 0.9em;
color: #ba1d1d;
font-weight: 400;
font-family: 'Roboto', sans-serif;
}


.account.deposit .lower .separate {
width: 100%;
height: auto;
/*cursor: pointer;*/
display: flex;
flex-wrap: wrap;
/*border: 0.2em solid blue;*/
}

.account.deposit .lower label.select {
width: 100%;
height: 2.88em;
padding: 0 0 0 0.4em;
margin: 0.2em 0 0.6em;
cursor: pointer;
display: flex;
align-items: center;
border-radius: 0.15em;
border: 0.1em solid #a8abb4;
}

.account.deposit input[type="radio"] {
cursor: pointer;
/*box-shadow: none !important;*/
font-size: 0.55em;
width: 2em;
height: 2em;
margin: 0 0.5em 0 0.43em;
border-radius: 50%;
-webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
border: 0.35em solid #a8abb4;
}

.account.deposit input[type="radio"]:checked {

box-shadow: 0 0 0.2em 0.15em #4299f0;
border: 0.35em solid #fff;
background: #4299f0;
}


.account.deposit label.select span {
font-weight: bold;
font-size: 0.93em;
width: 30%;
padding-left: 0.3em;
display: flex;
align-items: center;
color: #53545d;

/*border: 0.1em solid red;*/
}





.account.deposit label.select ul {
display: inline-flex;
width: 60%;
justify-content: flex-end;
/*border: 0.08em solid red;*/
}

.account.deposit label.select ul li {
width: 20%;
height: 2.2em;
/*margin-right: 0;*/
/*border: 0.08em solid red;*/
}

.account.deposit label.select ul li.visa {
background: url('/games.com/resources/vector/visa.svg') center no-repeat;
background-size: 4.4em 2.4em;
}
.account.deposit label.select ul li.master {
background: url('/games.com/resources/vector/master.svg') center no-repeat;
background-size: 4.4em 2.4em;
}
.account.deposit label.select ul li.amex {
background: url('/games.com/resources/vector/amex.svg') center no-repeat;
background-size: 2.8em 1.5em;
}
.account.deposit label.select ul li.jcb {
background: url('/games.com/resources/vector/jcb.svg') center no-repeat;
background-size: 4em 2em;
}
.account.deposit label.select ul li.discover {
background: url('/games.com/resources/vector/discover.svg') center no-repeat;
background-size: 4.4em 2.4em;
}

.account.deposit label.select ul li.paypal {
background: url('/games.com/resources/vector/paypal-big.svg') center no-repeat;
width: 5em;
height: 3em;
background-size: cover;
}
.account.deposit label.select ul li.stripe {
background: url('/games.com/resources/vector/stripe.svg') center no-repeat;
width: 4em;
background-size: cover;
}

.account.deposit label.select ul li.alipay {
background: url('/games.com/resources/vector/alipay.svg') center no-repeat;
width: 4em;
background-size: 4.4em 3.1em;
}

.account.deposit label.select ul li.bitcoin {
background: url('/games.com/resources/vector/bitcoin-2.svg') center no-repeat;
width: 4.5em;
background-size: cover;
}
.account.deposit label.select ul li.ethereum {
background: url('/games.com/resources/vector/ethereum.svg') center no-repeat;
width: 8em;
background-size: contain;
/*border: 0.08em solid red;*/
}



.account.deposit .details {
width: 100%;
padding: 0.5em 0.88em 0.8em;
min-height: 4em;
height: auto;
/*max-height: 8em;*/
max-height: 25em;
margin: 0 0 0.5em;
border-radius: 0.1em;
background: #f1f2f7;
display: none;
/*border: 0.08em solid red;*/
}

.account.deposit .details:nth-child(2).show {
display: block;
}
.account.deposit .details.show {
display: block;
}


.account.deposit label.select.others i.more {
color: #7a7e89;
font-size: 1em;
}
.account.deposit label.select.others:hover i {
color: #4299f0;
}
.account.deposit label.select.others span  {
width: 88%;
}
/*.account.deposit .wrapper.others {

}*/
.account.deposit .details.others {
background: #fff;
padding: 0;
/*display: block;*/
}

.account.deposit label.others.hide {
display: none;
}






.account.deposit .details ul li {
margin-top: 0;
/*border: 0.08em solid blue;*/
}

.account.deposit .double.month {
width: 38%;
}
.account.deposit .double.year {
width: 28%;
}
.account.deposit .double.security {
width: 30%;
}

.account.deposit .double.security i.point {
position: absolute;
cursor: pointer;
color: #56575d;
margin: -1.3em 0 0 5.5em;
font-size: 1.2em;
}

.account.deposit .double.security .info {
position: absolute;
width: 16em;
background: #272220;
padding: 0.6em 1em;
text-shadow: none;
text-align: left;
color: #c6c6cc;
font-size: 0.95em;
margin: -7em 0 0 0;
}


.account.deposit .lower .left h5 {
font-size: 0.8em;
font-weight: normal;
color: #2b2f36;
font-family: 'Roboto', sans-serif;
}
.account.deposit .lower .left h5 a {
color: #3b6cc9;
}
.account.deposit .lower .left h5 a:hover {
text-decoration: underline;
}



.account.deposit .lower button {
background: #40b93b;
font-size: 0.93em;
color: #f0f2f7;
font-weight: 400;
padding: 0.4em 2em;
width: 100%;
border-radius: 0.08em;
/*box-shadow: 0.1em 0.2em 0.3em 0 #40b93b;*/
}
.account.deposit .lower button:hover {
color: #f8f8f8;
background: #339f2e;
}
.account.deposit .lower button:active {
color: #f0f2f7;
background: #40b93b;
/*box-shadow: none;*/
}



.account.deposit .right.summary {
width: 41%;
height: 22em;
padding: 1em 0;
background: #f1f2f7;
border-radius: 0.1em;
margin-top: 5%;
border: 0.08em solid #e3e4ea;
}


.account.deposit .summary label.summary {
margin-left: 1em;
}


.account.deposit .summary label i {
font-size: 1.2em;
}
.account.deposit .summary label a {
color: #197ce0;
}


.account.deposit .summary ul {
min-height: 15em;
height: auto;
margin: 1em 0 0.8em;

border-bottom: 0.12em solid #d0d0d9;
}
.account.deposit .summary ul li {
padding: 0.9em 0;
font-size: 0.9em;
margin: 0.8em 1.1em;
border-bottom: 0.12em solid #d0d0d9;
}
.account.deposit .summary ul li label {
font-size: 0.98em;
width: 100%;
}

.account.deposit .summary label {
font-size: 0.84em;
color: #575865;
font-weight: bold;
}

.account.deposit .summary ul li label.name {
color: #63636c;
display: flex;
align-items: flex-start;
justify-content: space-between;
}

.account.deposit li label.name .value,
.account.deposit .summary label.last .value {
width: auto;
color: #484953;
}
.account.deposit .summary ul li p {
font-size: 0.93em;
width: 100%;
margin: 0.3em 0 0;
color: #34343b;
text-shadow: 0 0 0.5em #dbdbe5;
}
.account.deposit .summary ul li.last {
border: none;
}
.account.deposit .summary label.last {
float: right;
color: #7f7f88;
margin: 0 1em 1em;
}


</style>






<section class="account deposit">

<div class="logo-block">

	<label>Logo</label>

	<div class="language target">
		<i class="fas fa-globe-europe target"></i> &nbsp;English
		<div class="list target langbox">
			Spannish...
		</div>
	</div>

</div>


<div class="inner">

	<aside class="triangle"></aside>

	<main class="wrapper">

		<div class="lower">
			<div class="title">
				<label>Billing Details</label>

				<aside class="progress">
					<label class="one">
						<i class="fas fa-check done"></i>
					</label>&nbsp;Shopping cart 
					<hr><label class="two">2</label>&nbsp;Checkout
					<hr><label class="three">3</label>&nbsp;Finish
				</aside>

			</div>

			<form method="post" class="left deposit" autocomplete="off" novalidate="novalidate">

				<fieldset>
					<ul>
						<li>
							<label for="name">First & Surname</label>
							<input type="text" id="name" name="" autofocus placeholder="Enter First & Surname" maxlength="50">
						</li>

						<li class="double">
							<div class="state double">
								<label for="email">Email address</label>
								<input type="email" id="email" name="" placeholder="Enter email address" maxlength="50">
							</div>

							<div class="postal double">
								<label for="country">Country</label>
								<select id="country">
									<option>Country</option>
									<option>Nigeria</option>
									<option>Biafra</option>
									<option>United States</option>
									<option>Ghana</option>
								</select>
							</div>
						</li>


						<li class="double">
							<div class="state double">
								<label for="state">State/County</label>
								<input type="text" id="state" name="" placeholder="Enter State/County" maxlength="50">
							</div>

							<div class="postal double">
								<label for="postal">Zip/postal code</label>
								<input type="number" id="postal" name="" placeholder="Zip/postal code" maxlength="50">
							</div>
						</li>

					</ul>
					

			<br />

			<label class="method">
				Payment Method
			</label>

			<br />

			<div class="separate">

				<label for="credit" class="select">
					<input type="radio" id="credit" name="method" value="credit" checked="checked">
						<span>Credit Card</span>
						<ul>
							<li class="visa"></li>
							<li class="master"></li>
							<li class="amex"></li>
							<li class="jcb"></li>
							<li class="discover"></li>
						</ul>
					
				</label>
					<div class="details credit show">
						<ul>
							<li>
								<label for="card-number">Card number</label>
								<input type="number" id="card-number" name="" placeholder="Enter card number" maxlength="18">
							</li>

							<li class="double">
								<div class="double month">
									<label for="month">Expiration date</label>
									<select id="month">
										<option>Month</option>
										<option>Jan</option>
										<option>Feb</option>
										<option>Mar</option>
										<option>Apr</option>
										<option>May</option>
										<option>Jun</option>
										<option>Jul</option>
										<option>Aug</option>
										<option>Sep</option>
										<option>Oct</option>
										<option>Nov</option>
										<option>Dec</option>
									</select>
								</div>

								<div class="double year">
									<label for="year">&emsp;</label>
									<select id="year">
										<option>Year</option>
										<option>2035</option>
										<option>2034</option>
										<option>2033</option>
										<option>2032</option>
										<option>2031</option>
										<option>2030</option>
										<option>2029</option>
										<option>2028</option>
										<option>2027</option>
										<option>2026</option>
										<option>2025</option>
										<option>2024</option>
										<option>2023</option>
										<option>2022</option>
										<option>2021</option>
										<option>2020</option>
									</select>
								</div>

								<div class="double security">
									

									<label for="security">
										Security code&emsp;
										<i class="fas fa-question-circle point"></i>
										<span class="info">
											The three numbers printed at the back of your card.
										</span>
									</label>

									<input type="number" id="security" name="" placeholder="Three digits" max="3" maxlength="3" onKeyPress="if(this.value.length === 3) return false;">

									
								</div>
							</li>
						</ul>
					</div>


				<label for="paypal" class="select">
					<input type="radio" id="paypal" name="method" value="paypal">
					<span>Paypal</span>
					<ul>
						<li class="paypal"></li>
					</ul>
				</label>
				<div class="details paypal">
					paypal
				</div>

				<label for="others" class="select others">
					&ensp;<i class="fas fa-plus more"></i>&ensp;
					
					<span>Other payment Methods</span>
					<ul>
						<li class="others"></li>
					</ul>
				</label>

				<div class="details others">
					
					<label for="stripe" class="select">
					<input type="radio" id="stripe" name="method" value="stripe">
					<span>Stripe</span>
					<ul>
					<li class="stripe"></li>
					</ul>
					</label>
					<div class="details stripe">
					stripe
					</div>

					<label for="alipay" class="select">
					<input type="radio" id="alipay" name="method" value="alipay">
					<span>Alipay</span>
					<ul>
					<li class="alipay"></li>
					</ul>
					</label>
					<div class="details alipay">
					alipay
					</div>


					<label for="bitcoin" class="select">
					<input type="radio" id="bitcoin" name="method" value="bitcoin">
					<span>Bitcoin</span>
					<ul>
					<li class="bitcoin"></li>
					</ul>
					</label>
					<div class="details bitcoin">
					bitcoin
					</div>

					<label for="ethereum" class="select">
					<input type="radio" id="ethereum" name="method" value="ethereum">
					<span>Ethereum</span>
					<ul>
					<li class="ethereum"></li>
					</ul>
					</label>
					<div class="details ethereum">
					ethereum
					</div>

				</div>




			<!-- 	<label for="stripe" class="select">
					<input type="radio" id="stripe" name="method" value="stripe">
					<span>Stripe</span>
					<ul>
						<li class="stripe"></li>
					</ul>
				</label>
				<div class="details stripe">
					stripe
				</div>

				<label for="alipay" class="select">
					<input type="radio" id="alipay" name="method" value="alipay">
					<span>Alipay</span>
					<ul>
						<li class="alipay"></li>
					</ul>
				</label>
				<div class="details alipay">
					alipay
				</div>


				<label for="bitcoin" class="select">
					<input type="radio" id="bitcoin" name="method" value="bitcoin">
					<span>Bitcoin</span>
					<ul>
						<li class="bitcoin"></li>
					</ul>
				</label>
				<div class="details bitcoin">
					bitcoin
				</div>

				<label for="ethereum" class="select">
					<input type="radio" id="ethereum" name="method" value="ethereum">
					<span>Ethereum</span>
					<ul>
						<li class="ethereum"></li>
					</ul>
				</label>
				<div class="details ethereum">
					ethereum
				</div> -->


				<h5>By clicking the deposit funds, you agree to the 
					<a href="#">Terms & Conditions</a>
				</h5>
				
			</div>

				<br />

					<button>Deposit funds</button>
				</fieldset>
			</form>


		<aside class="right summary">
			<label class="summary">
				<i class="fas fa-donate"></i>&nbsp;
				Billing summary &nbsp;[<a href="#">Edit</a>]
			</label>
			<!-- <br /> -->

			<ul>
				<li>
					<label class="name">Reason
					<label class="value">$245.58</label></label>
					<p>
						Description...Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tequa. Ut enim ad minim veniam.
					</p>
				</li>

				<li class="last">
					<label class="name">Reason
						<label class="value">$245.58</label>
					</label>
					<p>
						Description...Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tequa. Ut enim ad minim veniam.
					</p>
				</li>

			</ul>
			<label class="last">SubTotal&ensp;<span class="value">$736.74</span></label>
		</aside>


		</div>
	</main>
</div>

<footer class="mini footer bottom">
	<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>
</footer>


</section>
<!-- <script src="assets/script/script.js"></script> -->


<script>
	


(function(){
    
        // ...Deposit page and Account page....
    
    var depositForm = $('form.deposit'),
        methods = $('form.deposit label.select'),
        activeBox = $('.account.deposit .details'),

        question = $('.payments .encompass ul.ques li'),
        activeExp = $('.payments .encompass ul.ques .content');

        depositForm.on('submit', function(e) {
            e.preventDefault();
        });


    function accordion(accoBtn, activeBox) {

        accoBtn.click(function(e) {
            let $this = $(this),
                block = $this.next(activeBox);
                block.find('input').val('');
                block.addClass('show');
                $this.addClass('active');

                accoBtn.not($this).each((index, obj)=> {
                    $(obj).removeClass('active');
                });

                activeBox.not(block).each((index, obj)=> {
                    $(obj).removeClass('show');
                });

                if($this.hasClass('others')) {
                    $this.addClass('hide');
                } 
        });
    }
    accordion(methods, activeBox);
    accordion(question, activeExp);

}());


</script>