<?php require 'header.php'; ?>
<?php require 'main.php'; ?>



<section class="account settings">


<div class="inner">

	<aside class="left-box part">
		
		<div class="wrapper">

			<div class="user-nav">
				<img src="/games.com/resources/picture/passport.jpg">
				<label>Anusionwu Chikeluba george</label>
				<div class="edit">
					<i class="far fa-edit"></i>
				</div>
			</div>

			<menu>

				<span class="notific icons">
					<i class="far fa-bell"></i>
					<span>Notif</span>
				</span>


				<span class="message icons">
					<i class="far fa-comment-alt"></i>
					<span>Mess</span>
				</span>

				<span class="setting icons">
					<i class="fas fa-cog"></i>
					<span>Sett</span>
				</span>

			</menu>

			<div class="search">
				<form>
					<input type="search" name="">
					<button>S</button>
				</form>			
			</div>

			<div class="users-list">
				uu...
			</div>
		</div>

	</aside>


	<div class="right-box part">

		<div class="wrapper">
			<aside class="left">

				<div class="content">
						<section class="xxx">
							<div class="receiver">
								<img src="/games.com/resources/picture/gamecare.png">
								<label>Ejike emmanual...sjahxdjasxsdcsbhdcjskd.xxxxx zippper</label>
								<span class="status"></span>
							</div>

							<div class="activity">
								
								<i class="fas fa-star"></i> <span>11</span>
								<i class="fas fa-trophy"></i> <span>3</span>
								<i class="fas fa-medal"></i> <span>7</span>
							</div>


						</section>



						<section class="yyy">
							Centre img...last seen..

							<button>Update</button>
							<br />
							<button>Cancel</button>
						</section>

						<section class="zzz">zzzz...</section>
				</div>
			</aside>


			<aside class="right">
				<div class="wrap">
					Voice Call... Video Call
				</div>
			</aside>
		</div>

	</div>



<!-- 	

	<br />

	Contact Preference

	<br />
	<br />
	<br />

Can I participate in a national lottery of a foreign country?<br />

How old do I need to be to play the lottery?<br />

What is the life cycle of my entry?<br />

What is the deadline for buying a ticket for the drawing?<br />

How many tickets can I buy for one draw in each lottery?<br />

Can I play if I don’t have a bank card?<br />

When are the results published?

How do I check if I’ve won?

Is there automatic notification of winnings?

Do I need to register to play?

How do I register?

Do I need to confirm my email address?

<br />
<br /> -->




</div>



<footer class="mini footer bottom setting">
	<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>
</footer>


</section>

<script src="assets/script/script.js"></script>





 