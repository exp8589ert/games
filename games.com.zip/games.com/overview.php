<?php require 'header.php'; ?>
<?php require 'main.php'; ?>
<?php require 'create.php'; ?>


<!-- Each player must have a limit time to play so another player can play. 45 seconds. -->


<section class="account body overview">

<div class="inner">


<aside class="left">
		<!-- use a subdomain here. https://account.games.com/en/overview



		On-Play -->


<?php include'search.php'; ?>



<div class="first profile">
<aside>
<img src="resources/picture/passport.jpg">	

<label class="experience">
	<span class="field">Experience &nbsp;

	<!-- <i class="fas fa-award"></i>  -->

</span><br /><span class="answer">
Grand Master</span></label>
<!-- Beginner, Graduate, Expert, Master, Grand Master and Legend. -->
</aside>

<aside class="username">
<div class="welcome">Welcome,</div> <br />

<div class="user">
	<span class="name">Michael Anusionwu Michael</span>
	
</div>

</aside>


</div>

<div class="second">
<label>xxxx xxxx</label>
<i class="far fa-edit edit"></i>
</div>


<div class="third">
<div class="btn-wrapper">

<a href="account.php">
	<button class="deposit"><i class="fas fa-plus"></i>&nbsp; Deposit</button>
</a>

<a href="account.php">
<button class="withdraw"><i class="fas fa-minus"></i>&nbsp; Withdraw</button>
</a>

<div class="info">
<i class="fab fa-algolia"></i>
</div>
</div>

<div class="rate">



<div class="chart">
	Currency Chart
</div>

<ul>
	<li>BTC <span>0.16406</span></li>
	<li>ETH <span>0.03495</span></li>
	<li>EUR <span>395.20</span></li>
	<li>GBP <span>215.35</span></li>
	<li>USD <span>5,428.18</span></li>	
</ul>



<!-- 

If you would like advice and support in relation to your gambling there are various support services you can turn to for help. Contact our Customer.

 -->

</div>


</div>


<div class="fouth">


 	<ul>
 		<li>
 			<label class="details">
 				<span class="date">09-Sep-2021 09:58</span>
			 	<span class="username">
			 		<a href="#">  
			 			<span class="value">eyiuche29</span> <span class="online"></span>
			 		</a>
			 	</span>
 			</label>
		 	<label class="comment">Chat-1 $80 Poker hit play to take up challenge.
		 	</label>
		 	<span class="accept">
			 	<a href="#">
		 			<i class="fas fa-dice-d20" title="Accept challenge"></i>
		 		</a>

		 		<a href="#" class="chat target">
		 			<i class="far fa-comment-alt target" title="Chat"></i>
			 	</a>
		 	</span>
 		</li>

 		<li>
 			<label class="details">
 				<span class="date">02-Feb-2021 07:58</span>
			 	<span class="username">
					<a href="#"> 
			 			<span class="value"> gamer4money</span> <span class="online"></span>
			 		</a>

				</span>
 			</label>
		 	<label class="comment">Chat-1 $80 Poker hit play to take up challenge Chat-1 $80 Poker hit play to take up challenge Make. Chat-1 $80 Poker hit play to take. God of vengane. Chat1 $80 Poker hit play to take. God of vengane.
		 	</label>
		 	<span class="accept">
		 		<a href="#" class="chat target">
		 			<i class="far fa-comment-alt target" title="Chat"></i>
			 	</a>

		 		<a href="#">
		 			<i class="far fa-check-circle" title="Accept challenge"></i>
		 		</a>
		 	</span>
 		</li>

 			<li>
 			<label class="details">
 				<span class="date">02-Feb-2021 07:58</span>
			 	<span class="username">
			 		<a href="#"> 
						
						<span class="value"> amenToeye</span> <span class="online"></span>
					</a>
			 	</span>
 			</label>
		 	<label class="comment">Chat-1 $80 Poker hit play to take up challenge Chat-1 $80 Poker hit play to take up challenge Make. Chat-1 $80 Poker hit play to take. God of vengane. Chat1 $80 Poker hit play to take. God of vengane.
		 	</label>
		 	<span class="accept">
		 		<a href="#">
		 			<!-- <i class="fas fa-dice-d20" title="Accept challenge"></i> -->

		 			<i class="fas fa-check" title="Accept challenge"></i>
		 		</a>
		 		<a href="#" class="chat target">
		 			<i class="far fa-comment-alt target" title="Chat"></i>
			 	</a>
		 	</span>
 		</li>

 			<li>
 			<label class="details">
 				<span class="date">02-Feb-2021 07:58</span>
			 	<span class="username">
			 		<a href="#"> 
						
						<span class="value">believ_Eamen</span> <span class=""></span>
					</a>
			 	</span>
 			</label>
		 	<label class="comment">Chat-1 $80 Poker hit play to take up challenge Chat-1 $80 Poker hit play to take up challenge Make. Chat-1 $80 Poker hit play to take. God of vengane. Chat1 $80 Poker hit play to take. God of vengane.
		 	</label>
		 	<span class="accept">
		 		<a href="#">
		 			<i class="fas fa-dice-d20" title="Accept challenge"></i>
		 		</a>

		 		<a href="#" class="chat target">
		 			<i class="far fa-comment-alt target" title="Chat"></i>
			 	</a>
		 	</span>
 		</li>

 			<li>
 			<label class="details">
 				<span class="date">02-Feb-2021 07:58</span>
			 	<span class="username">
			 		<a href="#"> 
						<span class="value"> chinaza23_f</span> <span class="online"></span>
					</a>
			 	</span>
 			</label>
		 	<label class="comment">Chat-1 $80 Poker hit play to take up challenge Chat-1 $80 Poker hit play to take up challenge Make. Chat-1 $80 Poker hit play to take. God of vengane. Chat1 $80 Poker hit play to take. God of vengane.
		 	</label>
		 	<span class="accept">
		 		<a href="#" class="chat target">
		 			<i class="far fa-comment-alt target" title="Chat"></i>
			 	</a>

		 		<a href="#">
		 			<i class="fas fa-check" title="Accept challenge"></i>
		 		</a>
		 	</span>
 		</li>

 			<li>
 			<label class="details">
 				<span class="date">02-Feb-2021 07:58</span>
			 	<span class="username">
			 		<a href="#"> 
						
						<span class="value"> abc23_ekene</span> <span class="online"></span>
					</a>
			 	</span>
 			</label>
		 	<label class="comment">Chat-1 $80 Poker hit play to take up challenge Chat-1 $80 Poker hit play to take up challenge Make. Chat-1 $80 Poker hit play to take. God of vengane. Chat1 $80 Poker hit play to take. God of vengane.
		 	</label>
		 	<span class="accept">
		 		<a href="#">
		 			<!-- <i class="fas fa-dice-d20" title="Accept challenge"></i> -->
		 			<i class="fas fa-check" title="Accept challenge"></i>
		 		</a>
		 		<a href="#" class="chat target">
		 			<i class="far fa-comment-alt target" title="Chat"></i>
			 	</a>
		 	</span>
 		</li>

 			<li>
 			<label class="details">
 				<span class="date">02-Feb-2021 07:58</span>
			 	<span class="username">
			 		<a href="#"> 
						
						<span class="value">gamer4money</span> <span class=""></span>
					</a>
			 	</span>
 			</label>
		 	<label class="comment">Chat-1 $80 Poker hit play to take up challenge Chat-1 $80 Poker hit play to take up challenge Make. Chat-1 $80 Poker hit play to take. God of vengane. Chat1 $80 Poker hit play to take. God of vengane.
		 	</label>
		 	<span class="accept">
		 		<a href="#">
		 			<i class="fas fa-check" title="Accept challenge"></i>
		 		</a>
		 		<a href="#" class="chat target">
		 			<i class="far fa-comment-alt target" title="Chat"></i>
			 	</a>
		 	</span>
 		</li>
 	</ul>




</div>

<div class="fifth">
	
	<form method="post" class="wrapper">

		<aside class="files">
			<i class="far fa-image img"></i>
			<!-- <input type="file" name=""> -->
		</aside>

		<div class="counter">
			<span class="wrap"><span class="char"></span> of 200</span>
		</div>
		<textarea 
			autocorrect="on" 
			spellcheck="spellcheck" 
			maxlength="200"  
			placeholder="Type a message here"></textarea>

		<aside class="emoji">
			<i class="far fa-smile smile"></i>
			<button type="submit">
				<!-- <i class="fas fa-play send"></i> -->
			</button>
		</aside>


		
	</form>




</div>


</aside>

	<aside class="centre">
		<div class="ingame">

					<div class="direction">
						<label class="prev side"><i class="fas fa-caret-left"></i> Prev</label>
						<label class="next side">Next <i class="fas fa-caret-right"></i></label>
					</div>

			<!-- Live players -->
			<ul class="player">
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
				<li><a href="#"></a></li>
			</ul>

<div class="perform record">
	<span class="medal cup"></span>

	<ul>
		<li>ID: <span>2A980FE6</span></li>
		<li>Username: <span>mendo92hi</span></li>
		<li>Highest Ranking: <span>Expert</span></li>
		<li>Game: <span>Chess</span></li>
		<li>Competition won: <span>12</span> in 25</li>
	</ul>

</div>

<div class="first">
<div class="second">
	<div class="third">

		<label class="tool-tip">
				<ul>

					<li>
						<i class="fas fa-user-check"></i>&ensp;
						<span class="username">gamer4money</span>
					</li>

					<li>
						<span>
							Ranking:
						</span>
						<span class="value">Beginner</span>
					</li>

					<li>
						<span>Best:</span>
						<span class="value">Poker</span>
					</li>

					<li class="count">
						<span>Total Played:</span>
						<span class="played count value">17</span>
					</li>

					<li>
						<span>Total Won:</span>
						<span class="won count value">12</span>
					</li>

				</ul>
		</label>

		<?php $gameId = 3; ?>


		<a href="challenge.php?id=<?= $gameId ?>" class="join game">
			<div class="fouth">
				
					<!-- <span class="timer">50 seconds remaining</span> -->

				<svg class="circle" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
					<path id="curve" 
							d="M 120,
								0 A 120,
								120 0 0 1 -120,
								0 A 120,
								120 0 0 1 120,
								0" 
							transform="translate(124 124) rotate(187)" fill="none" stroke="none" stroke-width="25"/>
					<text>
					<textPath xlink:href="#curve"><tspan dy="4.8">
					<tspan class="time">0</tspan> seconds remaining...</tspan></textPath>
					</text>
				</svg>



				<label class="info">
					<span class="total">10 Players</span>
					<span class="amount"><i class="fas fa-star"></i>&nbsp;$2,500.00</span>
					<span class="inplay">Prize to be won</span>
					<span class="inplay">Chess <i class="fas fa-chess"></i></span>
				</label>
			</div>
		</a>
		

	</div>
</div>
</div>

<a href="challenge.php" class="join">
	<button class="deposit">
		<div class="white">Join

		<div class="led-green"></div>

		</div>
	</button>
</a>


		</div>

		<div class="lower">
			<div class="onplay-news one">
				<div class="left block">wwwwww</div>
				<div class="right block">gggggg</div>
			</div>

			<div class="onplay-news two block">

				<label class="direction">
					<i class="fas fa-caret-up"></i>
					<i class="fas fa-caret-down"></i>
				</label>

				<ul>
					<li>
						<a href="#">
							<img src="/games.com/resources/picture/passport.jpg">
							<div>
								<span>Michael</span>, Won * $4,200 with 65% chances. 3hr 45 mins ago. Yes i made it to the finals.
							</div>
						</a>
					</li>

					<li>
						<a href="#">
							<img src="/games.com/resources/picture/passport.jpg">
							<div>
								<span>Ifeanyi</span>, Won * $4,200 with 65% chances. 3hr 45 mins ago. Yes i made it to the finals.
							</div>
						</a>
					</li>

					<li>
						<a href="#">
							<img src="/games.com/resources/picture/passport.jpg">
							<div>
								<span>Okonkwo</span>, Won * $4,200 with 65% chances. 3hr 45 mins ago. Yes i made it to the finals.
							</div>
						</a>
					</li>	


					<li>
						<a href="#">
							<img src="/games.com/resources/picture/passport.jpg">
							<div>
								<span>Peter</span>, Place a be $450.00 on Snooker.
							</div>
						</a>
					</li>

					<li>
						<a href="#">
							<img src="/games.com/resources/picture/passport.jpg">
							<div>
								<span>Chess tournament</span>, Emma created a $70.00 challenge.
							</div>
						</a>
						
					</li>

					<li>
						<a href="#">
							<img src="/games.com/resources/picture/passport.jpg">
							<div>
								<span>New release</span>: Introducing zetroit game. Multiple players enabled.
							</div>
						</a>
					</li>

					<li>
						<a href="#">
							<img src="/games.com/resources/picture/passport.jpg">
							<div>
								<span>Jideon</span>, Place a be $450.00 on Snooker.
							</div>
						</a>
					</li>

					<li>
						<a href="#">
							<img src="/games.com/resources/picture/passport.jpg">
							<div>
								<span>Chess tournament</span>, Emma created a $70.00 challenge.
							</div>
						</a>
						
					</li>
				<!-- 	<li>Top Winners</li>
					<li>Latest Winners</li>
					<li>Most Played</li> -->

				</ul>





			</div>

			<div class="onplay-news three block">
				xxxx xxxx
				
			</div>



		</div>



		


</aside>



<aside class="right">
		<nav>
			<ul class="tab ulist">
				<li class="active">Statistics</li>
				<li>History</li>
				<li>Transactions</li>
				<li>Top Players</li>
				<li>Performance</li>
			</ul>
		</nav>

	

<div class="container stats">

	
		<div class="details show">

			



			<!-- <canvas id="constarc" width="578" height="200"></canvas> -->

			
			<div class="user left">
				
				<div class="info login">
					<i class="far fa-user-circle"></i> &nbsp; 
						<span class="email"> gr***@gmail.com
						</span>
						 &nbsp; USER ID: <span class="id">4E0761K6</span>

						 <br />

						 Last login: &nbsp; 
						<span class="time">
							2021-02-15 23:20:29
						</span>
						&nbsp;
						IP: <span class="ip">	197.211.59.34
						</span>
				</div>

				<br />

				<div class="info count">
					
					<aside class="one">
						<label>
							<span>Grand Master</span>
							<br />
							Ranking
						</label>

						<label>
							<span>249</span> 
							<br />
							Total played
						</label>
					</aside>

					<aside class="two">
						<label>
							<span>349</span>
							<br />
							<a href="#">Followers</a>
						</label>

						<label>
							<span>871</span> 
							<br />
							<a href="#">Following</a>
						</label>
					</aside>

				</div>

				<div class="info count second">
					<br />
					<!-- <span>
						Accepted. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.
					</span> -->
				</div>
				 






		<!-- 

	

				<br />
				This will be in History section: Last challenge, With player: grand4love42.  

			<i class="fab fa-empire"></i>

		-->

			</div>



	<div class="bet percent">
		<canvas id="statistics" width="180" height="180"></canvas>
		<aside>
			<label>
				<span class="amount">$2,475.00</span>
				<br /><span class="stake">Total Stake</span></label>
			<label>
				<span class="amount">$3,830.00</span>
				<br /><span class="profit">Total Profit</span></label>
			<label>
				<span class="amount">$475.00</span>
				<br /><span class="loss">Total Loss</span></label>
		</aside>
	</div>


			<div class="inform">
				<!-- Performance review: <br />

				Currency: BTC/USD/EUR/GBP/YEN -->

				<ul>
					<li class="active">24 Hours</li>
					<li>Weekly</li>
					<li>Monthly</li>
					<li>6 Months</li>
					<li>1 Year</li>
					<li>2+ Years</li>
				</ul>


			</div>

			

			
		</div>


<div class="details history">

	<div class="pagination">
		<i class="fas fa-caret-left"></i>&ensp;
		<i class="fas fa-caret-right"></i>
	</div>

	<div class="wrappper">
		<table class="history">
			<thead>
				<th>S/N</th>
				<th>Game</th>
				<th>Stake</th>
				<th>Profit/Loss</th>
				<th>Date & Time</th>
			</thead>

			<tbody class="history">
				<script>
					for (var f = 1; f <= 28; f++) {
						$('tbody.history').append('<tr><td>'+f+'</td><td>Solitaire</td><td>70.00 USD</td><td><span class="plus">425.00 USD</span></td><td>04-12-2021 08:35 pm</td></tr><tr><td>'+f+'</td><td>Snooker</td><td>45.00 USD</td><td><span class="minus">70.00 USD</span></td><td>04-12-2021 08:35 pm</td></tr>')
					}
				</script>
			</tbody>
		</table>
	</div>
	
</div>



<div class="details transaction">

<div class="pagination">
	<i class="fas fa-caret-left"></i>&ensp;
	<i class="fas fa-caret-right"></i>
</div>

<div class="wrappper">
<table>
	<thead>
		<th>S/N</th>
		<th>Type</th>
		<th>Amount</th>
		<th>Status</th>
		<th>Date</th>
	</thead>

	<tbody class="transaction">

		<script>
			for (var f = 1; f <= 28; f++) {
				$('tbody.transaction').append('<tr><td>'+f+'</td><td>Withdrawal <span class="currency">BTC</span></td><td>0.09 <span class="currency">BTC</span></td><td>Completed <span class="complete"></td><td>04-12-2021 08:35 pm</td></tr><tr><td>'+f+'</td><td>Deposit <span class="currency">BTC</span></td><td>0.0162 <span class="currency">BTC</span></td><td>Pending <span class="pending"></span></td><td>19-03-2021 03:22 am</td></tr></tr><tr><td>'+f+'</td><td>Deposit <span class="currency">BTC</span></td><td>0.0162 <span class="currency">BTC</span></td><td>Failed <span class="failed"></span></td><td>19-03-2021 03:22 am</td></tr>')
			}
		</script>

		

	</tbody>
</table>
</div>

</div>



<div class="details top players">
	<div class="pagination">
		<i class="fas fa-caret-left"></i>&ensp;
		<i class="fas fa-caret-right"></i>
	</div>

	<div class="wrappper top players">
		<ul>
			<li>
				<img src="resources/picture/passport.jpg">

				<div>Lorem ipsum dolor sit amet, consectetur adipisicing elite. 

					<i class="fas fa-star"></i>
					<i class="fas fa-trophy"></i>
					<i class="fas fa-medal"></i>

				</div>

			</li>

			<li>
				<img src="resources/picture/passport.jpg">

				<div>Lorem ipsum dolor sit amet, consectetur adipisicing elite. <i class="fas fa-star"></i>
				</div>

			</li>

			<li>
				<img src="resources/picture/passport.jpg">

				<div>Lorem ipsum dolor sit amet, consectetur adipisicing elite. <i class="fas fa-star"></i>
				</div>

			</li>

			<li>
				<img src="resources/picture/passport.jpg">

				<div>Lorem ipsum dolor sit amet, consectetur adipisicing elite. <i class="fas fa-star"></i>
				</div>

			</li>

			<li>
				<img src="resources/picture/passport.jpg">

				<div>Lorem ipsum dolor sit amet, consectetur adipisicing elite. <i class="fas fa-star"></i>
				</div>

			</li>

			<li>
				<img src="resources/picture/passport.jpg">

				<div>Lorem ipsum dolor sit amet, consectetur adipisicing elite. <i class="fas fa-star"></i>
				</div>

			</li>

			<li>
				<img src="resources/picture/passport.jpg">

				<div>Lorem ipsum dolor sit amet, consectetur adipisicing elite. <i class="fas fa-star"></i>
				</div>

			</li>

			<li>
				<img src="resources/picture/passport.jpg">

				<div>Lorem ipsum dolor sit amet, consectetur adipisicing elite. <i class="fas fa-star"></i>
				</div>

			</li>


		</ul>
	</div>
	<br />
</div>


<div class="details performance">

<div class="perform">
		<ul class="info">
			<li class="one">Competition</li>
			<li class="two">Average Win</li>
			<li class="three">Average Loss</li>
		</ul>

<div class="bar-chart">

	<svg class="text" xmlns="http://www.w3.org/2000/svg"
  xmlns:xlink="http://www.w3.org/1999/xlink">
		<text x="8" y="100">Grand Total</text>
	</svg>

	<ul class="vert">
		<li>50000+</li>
		<li>20000</li>
		<li>10000</li>
		<li>5000</li>
		<li>1000</li>
		<li>0</li>
	</ul>

	<svg class="chart" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

		<rect x='8' y='58' class="one Q1" />
		<rect x='36' y='58' class="two Q1" />
		<rect x='64' y='58' class="three Q1" />

		<rect x='121' y='58' class="one Q2" />
		<rect x='149' y='58' class="two Q2" />
		<rect x='177' y='58' class="three Q2" />

		<rect x='234' y='58' class="one Q3" />
		<rect x='262' y='58' class="two Q3" />
		<rect x='290' y='58' class="three Q3" />

		<rect x='347' y='58' class="one Q4" />
		<rect x='375' y='58' class="two Q4" />
		<rect x='403' y='58' class="three Q4" />

	</svg>
</div>

<ul class="horiz">
	<li>2021 Q1</li>
	<li>2021 Q2</li>
	<li>2021 Q3</li>
	<li>2021 Q4</li>
</ul>


		<!-- Competition...
		Average...

		 <canvas></canvas> 
		<svg class="circle" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

		</svg> -->


	</div>

	
	<br />
</div>





<!-- 
Cancelled, Pending, Failed 
Deposit Crypto, Bet Crypto, Bet Dollar
-->



			
		





	

</div>	





	<div class="lower ustats first">
		<label class="">
			
			<i class="fab fa-hornbill"></i>
			&nbsp;
			Popular games
		</label>


		<ul class="popular games">
			<script>
				var links = [
					'google.com', 
					'twitter.com'
				],
				x, num = 24;
				for(x = 0; x < num; x++) {
					$('ul.popular.games').append('<a href="#" data-gameid="'+ x +'" class="show btn"><li><div><span><i class="fas fa-circle"></i></span><button class="play btn">Play</button></div></li></a>');
				}
			</script>
		</ul>
	</div>

	<div class="lower ustats second">

		<ul>

			<a href="#"><li>Find Players</li></a>
			<a href="#"><li>Terms of Use</li></a>
			<a href="#"><li>Help Center</li></a>
			<a href="#"><li>Copyright Policy</li></a>
			<a href="#"><li>Privacy Policy</li></a>
			<a href="#"><li>Developers</li></a>


		</ul>

	</div>
 
</aside>


<section class="last section">

	<div class="left"></div>

	<div class="right">

		<label>
			<i class="far fa-gem"></i> &nbsp;Selected For You 
		</label>

		<ul>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>games</li></a>
			<a href="catalogue.php#id?"><li>1..games</li></a>
			<a href="catalogue.php#id?"><li>2..games</li></a>
			<a href="catalogue.php#id?"><li>3..games</li></a>
			<a href="catalogue.php#id?"><li>4..games</li></a>
		</ul>

	</div>


</section>


</div>




<footer class="mini footer bottom">

	<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>

</footer>


</section>


<!-- div.fouth ul li 2449 -->


<div class="chat pop out target chatbox">

	<label class="close end">
		<i class="fas fa-times end"></i>
	</label>

	<div class="top layer">
		<a href="#">
			<img src="resources/picture/passport.jpg">
			<span class="online"></span>
			<label class="user details">
				<div class="name">hotplayer14</div>
				<br />
				<span class="last seen">Last seen 3 hours ago</span>
			</label>
		</a>
		
		<div class="phone items"><span></span></div>
		<div class="video items"><span></span></div>
		<div class="menu items"><span></span></div>
	</div>


	<div class="centre layer">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</div>



	<div class="bottom layer">
		<form method="post" enctype="multipart/form-data" novalidate="novalidate">	

			<div class="box up">
				<span class="photo icon"></span>
				<span class="emoji icon"></span>
			</div>
				
			<div class="box down">
				<textarea 
					autocorrect="on" 
					spellcheck="spellcheck" 
					maxlength="400"  
					placeholder="Type a message here"></textarea>
					<button>Send</button>
			</div>
		</form>
	</div>
</div>


<div id="transparent" class="overview"></div>
<script src="assets/script/script.js"></script>


