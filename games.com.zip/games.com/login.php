<?php require 'header.php' ?>


<header class="register login head">
	<div class="inner">
		
		<a href="http://localhost:81/games.com/">
				<aside class="logo">
					P4PGames
				</aside>
		</a>

		<aside class="translation">

			<div class="languages">
				French, Chinese, Spain..e.t.c.
			</div>

			
			<i class="fas fa-globe-europe"></i>&nbsp; English &nbsp; <i class="fas fa-caret-down"></i>

			
		</aside>


	</div>
</header>

<section class="reg-wrapper">

<div class="register login">
	<form method="post" autocomplete="off" novalidate="novalidate">
	
	<fieldset>
		<h3>Log In
			<br />
		</h3>
			

			<div class="secured preview">
              <label class="instruct">Please check that you are visiting the correct Link </label>

              	<br />
              	<br />

                <label class="link">
                  <span class="green">
                    <span class="lock"></span> &nbsp;https://accounts
                  </span>.p4pgames.com
                </label>
            </div>

		<br />
		<br />


		<div class="email login">
			<label>Email Address</label>
			<input type="email" autocomplete="off" name="" value="" placeholder="Enter email" autofocus>

			<label>Password</label>
			<input type="password" autocomplete="off" name="" value="" placeholder="Enter password">
		</div>


		<div class="phone num login">
			<label>Mobile</label>
			<input type="email" autocomplete="off" name="" value="" placeholder="" autofocus>

			<label>Password</label>
			<input type="password" autocomplete="off" name="" value="" placeholder="Enter password">
		</div>




		<br />
		<button type="submit">Log In</button>

		<br />
		<br />
		<br />

		<div class="notice links"> 
			<a href="#">Forgot Password?</a> 
			<a href="#">Scan to login</a> 
			<a href="register.php">Free registration</a>
		</div>	
	</fieldset>
	</form>
</div>


</section>





<footer class="mini bottom">
	<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>
</footer>

<script src="assets/script/script.js"></script>


