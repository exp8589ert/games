<footer class="footer index"> 
	<div class="inner">
		<div class="top">
			

			<div class="sports-logo">
				<ul>
					<li class="responsible"></li>
					<li class="license"></li>
					<li class="approved"></li>
					<li class="locked"></li>
					<li class="withdraw"></li>
				</ul>
			</div>
			<table>
				<thead>
					<th>About Us</th>
					<th>Games</th>
					<th>Services</th>
					<th>Support</th>
					<th>Learn</th>
					<th>Community</th>
				</thead>
				<tbody>
					<tr>
						<td><a href="overview.php">p4pgames.com</a></td>
						<td><a href="#">Card games</a></td>
						<td><a href="#">Downloads</a></td>
						<td><a href="#">Send Us Feedback</a></td>
						<td><a href="#">Tutorials</a></td>
						<td>
							<div class="community">
								<a href="#">
									<div class="facebook">
										<i class="fab fa-facebook"></i>
									</div>
								</a>
								<a href="#">
									<div class="instagram">
										<i class="fab fa-instagram"></i>
									</div>
								</a>
								<a href="#">
									<div class="vk">
										<i class="fab fa-vk"></i>
									</div>
								</a>
							</div>
						</td>
					</tr>

					<tr>
						<td><a href="#">Find a Player</a></td>
						<td><a href="#">Online Casino</a></td>
						<td><a href="#">Exchange</a></td>
						<td><a href="#">Submit a Request</a></td>
						<td><a href="#">Refer & Earn</a></td>
					</tr>

					<tr>
						<td><a href="#">Privacy Policy</a></td>
						<td><a href="#">Academic games</a></td>
						<td><a href="#">Deposit</a></td>
						<td><a href="#">Help Center</a></td>
						<td><a href="#">Security Guides</a></td>
						<td>
							<div class="community second">
								<a href="https://twitter.com/home">
									<div class="twitter">
										<i class="fab fa-twitter-square"></i>
									</div>
								</a>
								<a href="#">
									<div class="youtube">
										<i class="fab fa-youtube-square"></i>
									</div>
								</a>
								<a href="#">
									<div class="telegram ">
										<i class="fab fa-telegram"></i>
									</div>
								</a>
							</div>
						</td>
					</tr>

					<tr>
						<td><a href="#">Legal Policies</a></td>
						<td><a href="#">Lottery Draw</a></td>
						<td><a href="#">Developers</a></td>
						<td><a href="#">Sign Up</a></td>
						<td><a href="#">Buy Ethereum</a></td>
					</tr>

				<tr>
					<td><a href="#">Copyright</a></td>
					<td><a href="#">Board games</a></td>
					<td><a href="#">Withdraw</a></td>
					<td><a href="#">Investor relations</a></td>
					<td><a href="#">Buy Bitcoin</a></td>
					<td>
						<div class="community translate">
							
							<div class="languages">
								French, Chinese, Spain..e.t.c.
							</div>


							<label>
								<i class="fas fa-globe-europe"></i>&nbsp; English &nbsp; <i class="fas fa-caret-down"></i>
							</label>


						</div>
					</td>
				</tr>

				</tbody>
			</table>
			<div class="payments">
				<ul>
					<li class="adult"></li>
					<li class="mastercard"></li>
					<li class="visacard"></li>
					<li class="paypal"></li>
					<li class="stripe"></li>
					<li class="bitcoin"></li>
					<a href="https://www.gamcare.org.uk" class="gamecare" target="_blank"><li class="gamecare"></li></a>
				</ul>
			</div>
		</div>
		<div class="bottom">
			© 2014 - 2021 p4pgames.com. All rights reserved.
		</div>
	</div>
</footer>

<script src="assets/script/script.js"></script>

<!-- <script type="text/javascript" src="nwmatcher.js"></script> 
<script type="text/javascript" src="selectivizr-min.js"></script> -->


</body>
</html>