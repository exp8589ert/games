
<section id="create" class="modal target close">

<div class="challenge inner">


<div class="division top">
	<i class="far fa-times-circle close"></i>
</div>


<div class="division centre">	
	<div class="partition top">

<aside class="left">
	<label>Create Challenge&nbsp;
		<i class="far fa-edit"></i>
	</label>

	<div class="left lower">

		<h4>Create creteria and wait for contenders.</h4>

		<form>
			<ul>
				<li>
					<span>Title:
						<span>Solitaire</span>
					</span>
					

					<span class="genre">Genre:
						<span>Casino</span>
					</span>
				</li>
				
				<li>
					<span>Challenge #:
						<span>650NE059</span>
					</span>

				</li>
				
				<li>
					<span>
					<span class="min players">Min. players</span>&nbsp;
					  		<input 
							type="number" 
							name=""
							value="2" 
							min="2" 
							max="10" 
							disabled="disabled" 
							autofocus="autofocus" 
							ng-model="number" 
							onKeyPress="if(this.value.length === 2) return false;" >
					</span>

					<span>
					<span class="min players">Max. players</span>&nbsp;
					  		<input 
							type="number" 
							name=""
							value="2" 
							min="2" 
							max="10" 
							autofocus="autofocus" 
							ng-model="number" 
							onKeyPress="if(this.value.length === 2) return false;" >
					</span>

				</li>
				
				<!-- <li> 
					possible to stake, Bitcoin, euro, dollar, ethereum.

					<label class="player number"><i class="fas fa-minus"></i>
						<input 
						type="number" 
						name=""
						value="2" 
						min="2" 
						max="10" 
						ng-model="number" 
						onKeyPress="if(this.value.length === 2) return false;" >
						<i class="fas fa-plus"></i>
					</label>
				</li> -->


				<li class="stake">Stake amount 

				  <span>
				  <span class="currency">
				  	Stake currency <br />
				  	<select>
				  		<option>BTC</option>
				  		<option>ETH</option>
				  		<option>EUR</option>
				  		<option>GBP</option>
				  		<option>USD</option>
				  	</select>

				  </span>&nbsp;
				  		<input 
						type="number" 
						name=""
						value="2" 
						min="2" 
						max="10" 
						ng-model="number" 
						onKeyPress="if(this.value.length === 4) return false;" >
				</span>

				</li>

				<li>Begins in <span class="time">30 Mins.</span></li>
			</ul>
		</form>

	</div>

</aside>

<aside class="right">

	<div class="image"></div>

	<div class="desc">
		<i class="far fa-lightbulb"></i> <span class="game id"># 2ED5V456</span>
		<br />
		<br />
		&emsp; Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo. consequat. Duis aute irure dolor in reprehenderit in voluptate velit essea qui officia deserunt mollit..
	</div>


	<div class="demo">
		<label><i class="fas fa-futbol"></i>&nbsp; Demo</label>
		<label>dsdsdsd</label>
	</div>

</aside>

</div>

<!-- 
<i class="fas fa-futbol"></i> -->

<div class="partition bottom">xxxxx xxxx</div>



</div>


<div class="division bottom">
	<button>Create
		<i class="fas fa-check"></i>
	</button>
	<button>Cancel</button>
</div>





</div>

</section>