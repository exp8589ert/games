<?php require 'header.php'; ?>
<?php require 'main.php'; ?>
<?php require'create.php'; ?>


<section class="account body overview" id="catalogue">

<div class="inner">



	<div class="game list">

<!-- Action games
Action-adventure games
Adventure games
Role-playing games
Simulation games
Strategy games
Sports games
Puzzle games
Idle games -->

		<div class="upper-most">
			<ul>
				<li class="active">All Genres</li>
				<li>Arcademics</li>
				<li>Board games</li>
				<li>Lottery Draw</li>
				<li>Casino & Poker</li>
				<li>Trending Now</li>
				<li>New Release</li>
				<li>Most Popular</li>
				<li>Favourites</li>
			</ul>

			<div class="search-wrapper">
				<?php include'search.php'; ?>
			</div>

		</div>


<!-- <div class="tab-wrapper"> -->
			
		
		<div class="top first">
			<div class="bg-image"></div>
			<div class="content">
				<div>

					Select from numerous online games for all generations.<br />
					Earn upto 2,000 pounds on a single competition.
				</div>
			</div>
		</div>

		<div class="bottom">
			<div class="wrapper top">
				<aside class="left big game image img-1">

					
						<!-- <label></label> -->
						
						<button class="show btn">Play Now</button>
						<!-- Left .....
						rectangular list.
						<br />
						No. of people who played it.
						<br />
						Collective stake.
						<br /> -->
						
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp show btn"></div>

				</aside>

				<aside class="right">
					<div class="two-in-one">
						<div class="game image">
							

							<button class="show btn">Play Now</button>

							<label class="demo">Demo</label>
							<label class="info">Info</label>
							<div class="transp show btn">xxx</div>
							
						</div>
						<div class="game image">
							<button class="show btn">Play Now</button>

							<label class="demo">Demo</label>
							<label class="info">Info</label>
							<div class="transp"></div>
						</div>
					</div>

					<div class="two-in-one">
						<div class="game image">
							<button class="show btn">Play Now</button>

							<label class="demo">Demo</label>
							<label class="info">Info</label>
							<div class="transp"></div>
						</div>
						<div class="game image">
							<button class="show btn">Play Now</button>

							<label class="demo">Demo</label>
							<label class="info">Info</label>
							<div class="transp"></div>
						</div>
					</div>

				</aside>
			</div>

			<div class="list-title"><i class="fab fa-empire"></i> Game Shows</div>

			<div class="wrapper top second">
				<ul>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>


					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
				</ul>
			</div>



			<div class="list-title"><i class="fab fa-empire"></i> Popular games</div>



			<div class="wrapper top last">
				<ul>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
				</ul>
			</div>


			<div class="wrapper top">
				<aside class="left big game image img-45">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
				</aside>

				<aside class="right">
					<div class="two-in-one">
						<div class="game image">
							<button class="show btn">Play Now</button>
							<label class="demo">Demo</label>
							<label class="info">Info</label>
							<div class="transp"></div>
						</div>
						<div class="game image">
							<button class="show btn">Play Now</button>
							<label class="demo">Demo</label>
							<label class="info">Info</label>
							<div class="transp"></div>
						</div>
					</div>

					<div class="two-in-one">
						<div class="game image">
							<button class="show btn">Play Now</button>
							<label class="demo">Demo</label>
							<label class="info">Info</label>
							<div class="transp"></div>
						</div>
						<div class="game image">
							<button class="show btn">Play Now</button>
							<label class="demo">Demo</label>
							<label class="info">Info</label>
							<div class="transp"></div>
						</div>
					</div>

				</aside>
			</div>


		<div class="list-title"><i class="fab fa-empire"></i> Game Shows</div>

			
			<div class="wrapper top second square">
				<ul>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>

					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>
					<li class="game image">
						<button class="show btn">Play Now</button>
						<label class="demo">Demo</label>
						<label class="info">Info</label>
						<div class="transp"></div>
					</li>


				</ul>
			</div>


		<div class="list-title"><i class="fab fa-empire"></i> Game Shows</div>

		<div class="wrapper top second">
			<ul>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>
				<li class="game image">
					<button class="show btn">Play Now</button>
					<label class="demo">Demo</label>
					<label class="info">Info</label>
					<div class="transp"></div>
				</li>

			</ul>
		</div>

<!-- Total of 58 games. -->

		<div class="desc">
		

			<ul class="first">
				<li><a href="#">Statement</a></li>
				<li><a href="#">Affiliate</a></li>
				<li><a href="#">Developers</a></li>
				<li><a href="#">Support</a></li>
			</ul>


			<ul class="last">
				<li>
					<h3>Betfair’s online casino</h3>
					 is where all the action is at! It’s regarded by many as the best state-of-the-art online casino, thanks to our huge library of classic and next-generation casino games.

				We are partnered with many of the industry’s pioneering software developers to give you the best casino games and technology.

				Whether it’s the old classic slots and table games or our immersive 24/7 live casino action, you can experience the thrill of casino online betting from the comfort of your own home. We’re ready for you if you enjoy playing online casino games on the go too, with native iOS and Android casino apps giving you fun and secure gaming on tap.

				Better still, when you create a Betfair Casino account, you can take full advantage of our new customer sign-up bonus, giving you more bang for your buck on the tables and reels. Our casino promotions online don’t end there either. We regularly reward our regular players with reload offers to turbocharge your casino gaming!
				</li>

				<li>Betfair’s online casino is where all the action is at! It’s regarded by many as the best state-of-the-art online casino, thanks to our huge library of classic and next-generation casino games.

				We are partnered with many of the industry’s pioneering software developers to give you the best casino games and technology.

				Whether it’s the old classic slots and table games or our immersive 24/7 live casino action, you can experience the thrill of casino online betting from the comfort of your own home. We’re ready for you if you enjoy playing online casino games on the go too, with native iOS and Android casino apps giving you fun and secure gaming on tap.

				<br />
				<br />

				Better still, when you create a Betfair Casino account, you can take full advantage of our new customer sign-up bonus, giving you more bang for your buck on the tables and reels. Our casino promotions online don’t end there either. We regularly reward our regular players with reload offers to turbocharge your casino gaming!
				</li>

				<li>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 

					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 	
					<br />
					<br />

					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 

					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 
				</li>

				<li>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 

					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 
					<br />
					<br />
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 
				</li>

				<li>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 
					do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 
				</li>

				<li>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 
				</li>

				<li>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 

					do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 

					do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 
				</li>
				<li>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 

					do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. 
				</li>

				<li>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.

					do eiusmod. tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.  
				</li>

			</ul>



		</div>


		</div>
	</div>

</div>




	<!--

	<div class="right-tab">
		

		<br />
		<br />

		New Customer Offer<br />

		Daily Rewards For Every Player: <br />
		This Sports Promotion is available to qualifying customers until further notice. If we decide to withdraw this Sports Promotion, this will not impact any Qualifying Bets you have placed during the Promotional Period before such withdrawal.

		<br />

		Coin....	.	Predict	Payout...		Reward...	


		Profit...Wagered....Lost...Won...Streak
		<br />
		Game details... Game list

	</div>

	-->




<br />







</div>

	<footer class="footer mini bottom">
		<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>
	</footer>


</section>

<div id="transparent" class="overview"></div>
<script src="assets/script/script.js"></script>

