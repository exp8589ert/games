

<header class="account head main">
	

<div class="inner upper main">


<div class="content">
	
	<aside class="left">
		<div class="logo">
			<a href="http://localhost:81/games.com/overview.php">
				P4P Games
			</a>
		</div>

		<ul class="list">
			<a href="#">
				<li><i class="fas fa-dice-d20"></i>&nbsp; My Bonuses</li>
			</a>
		<!-- 	<a href="https://google.com"><li>
				<i class="fas fa-history"></i>&nbsp; Play History</li>
			</a> -->
			
			<a href="#">
				<li><i class="fas fa-life-ring"></i>&nbsp; Help</li>
			</a>
		</ul>

	</aside>

	<aside class="right">

		<aside class="download">

			<label class="mobile">Download &nbsp;<i class="fas fa-mobile-alt"></i>

		<div class="barcode hover-display">
		  <div><img src="">Barcode</div>
		  <div>Scan to Download App IOS & Android</div>
		  <div>
		  	
		  		<button>
		  		<a href="https://google.com">More Download Options
		  		</a>
		  	    </button>
		  	
		  </div>
		</div>

		</label>

		</aside>

		<aside class="deposit">
			<a href="payments.php">
				Deposit &nbsp;
				<i class="fas fa-donate"></i>
			</a>
		</aside>

		<aside class="account menu">
			<label>
				Menu &nbsp;
				<!-- <i class="fas fa-chevron-down" aria-hidden="true"></i> -->

				<i class="fas fa-caret-down caret" aria-hidden="true"></i>

				<div class="tray">
					<ul>
						<li>
							<i class="far fa-bell"></i>
							Notification
							<span>34</span>
						</li>
						<li>
							<i class="fas fa-user-lock"></i>
							Player Protection
						</li>
						
						<a href="settings.php">
							<li>
							
							<i class="fas fa-envelope-open-text"></i>
							Messages
							<span>34</span>

							</li>
						</a>
							
						<a href="settings.php">
							<li>
								<i class="fa fa-cogs settings" aria-hidden="true"></i>
								Settings
							</li>
						</a>

						<a href="faq.php">
							<li>
								<i class="far fa-question-circle"></i>
								Question & Answers
							</li>
						</a>

						<li>
							<i class="fas fa-power-off"></i>&nbsp;Log Out
						</li>

					</ul>
				</div>

			</label>
		</aside>

		<aside class="balance target">
			<ul>
				<li>Main Balance <span>$5800.00</span></li>
				<li>Performance <span>$750.25</span></li>
			</ul>

			<i class="fas fa-caret-down caret" aria-hidden="true"></i>

			<div class="sheet target sheetbox">
				<ul>
					<li>
						<div>
							<span class="bold">
							Main Balance <br />
								<span>(Balance accessible)</span>
							</span>
					
							<span class="value">
								<span>570.00 USD</span><br />
								<span>0.10750 BTC</span><br />
								<span>0.20320 ETH</span>
							</span>
						</div>

						<a href="account.php" class="hide-acc">
							<!-- My Account -->
							<img src="/games.com/resources/picture/passport.jpg">
							<span>grand4love</span>
						</a>

					</li>

					<li>
						<div>
							<span class="bold">
								Bonus Balance <br />
								<span>(xxxxx lorem explanation ...)</span>
							</span>
							<span class="value">$175.50</span>
						</div>
					</li>

					<li>
						<div>
							<span class="bold">
								Main Wallet<br />
								<span>(xxxxx lorem explanation ...)</span>
							</span>
							<span class="value">$350.00</span>
						</div>

							<span>
								<a href="account.php">Deposit</a> &ensp;|&ensp;<a href="account.php">Withdraw</a> 
							</span>

						
					</li>
					
					<li>
						<div>
							<span class="bold">Referral Bonus: 
							</span>
							<span class="value">$2,350.80</span>
						</div>

					</li>
					<li>
						<span>
							See full details in
							<a href="account.php">account summary</a>
						</span>
					</li>
				</ul>
			</div>


		</aside>


		<aside class="refresh" data-info="Refresh Balance">
			<i class="fas fa-sync-alt"></i>
		</aside>

		<aside class="translate">
			<label class="change target">
			English 
			<!-- &nbsp;<i class="fas fa-globe-europe"></i> -->
				<div class="list target langbox">
					Spannish...
				</div>
			</label>
		</aside>

	</aside>

</div>

</div>

<div class="inner lower main">
	<div class="content">
		<ul class="mini">
			<a href="/games.com/catalogue.php"><li>Game List</li></a>
			<!-- <a href="live.php"><li>In-Play</li> -->
			<a href="challenge.php"><li>Challenge &nbsp;<i class="fas fa-stopwatch"></i></li>
			<a href="#"><li>Demo</li>
			<a href="referral.php"><li>Refer and Earn</li></a>
			<a href="#"><li>Chess &nbsp;<i class="fas fa-chess"></i></li></a>
			<a href="#"><li>Snooker &nbsp;<i class="fas fa-slash"></i></li></a>
			<a href="#"><li>Bowling &nbsp;<i class="fas fa-bowling-ball"></i></li></a>
			<a href="#"><li>Scrabble &nbsp;<i class="fas fa-puzzle-piece"></i></li></a>
			<a href="#"><li>Dice &nbsp;<i class="fas fa-dice"></i></li></a>
			<a href="#"><li>Poker &nbsp;<i class="far fa-heart"></i></li></a>
		</ul>
	</div>
</div>

</header>