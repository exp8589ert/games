<form class="search" method="post">
	<input type="search" name="" autocomplete="off" spellcheck="spellcheck" placeholder="Search" maxlength="50">
	<button type="submit">
		<i class="fas fa-search"></i>
	</button>
</form>