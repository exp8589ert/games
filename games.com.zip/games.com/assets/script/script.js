$(document).ready(function() {

autosize($('textarea'));


$('form.login input[name="email"]').one('focus', (e)=> {
    $('.secured.preview').animate({
    }, 100, function() {
        let $this = this;
        $($this).addClass('show');
        // $('.secured.preview i.close').click(()=> {
        //     $($this).removeClass('show');
        // })
    });
});





(function() {
    /* ==== 
    Carousel function, index page. 
    ==== */

    var homeImg = [
        'resources/picture/home-1.png',
        'resources/picture/home-2.png',
        'resources/picture/home-3.png',
        'resources/picture/home-4.png',
        'resources/picture/home-5.png',
        'resources/picture/home-6.png'
    ],
    imgUL = $('.head-wrapper ul.images'),
    direction = $(".digital [class*='dir']"),
    counter = constNum = homeImg.length,
    spanFirstChild = $('span.side:first-child'),
    carousel = {
        thumbnail(count) { 
            $('.slide.dot span').each(function(index, elem) {
                (count === index)? 
                $(this).addClass('active') : 
                $(this).removeClass('active');
            });
        },
        CALLanimation() {
            $('ul.images img').animate({
                opacity: '0.4'
            }, 300, 'linear', function() {
                $(this).css('opacity', '1').attr('src', homeImg[counter]);
            });
        },
        LEFTclick() {
            counter--;
            if(counter < 0) counter = constNum - 1;
            this.CALLanimation();
            this.thumbnail(counter);
        },
        RIGHTclick(count) {
            counter++;
            if(counter >= constNum) counter = 0;
            this.CALLanimation();
            this.thumbnail(counter);
        }
    }
    
    for(var g = 1; g <= counter; g++) {
        $('.slide.dot').append('<span class="side dir"></span>'); 
    }
    spanFirstChild.addClass('active');
    carousel.thumbnail(counter);
    carousel.RIGHTclick();

    direction.click((e)=> {
        ($(e.currentTarget).hasClass('left'))?
            carousel.LEFTclick(counter) : 
            carousel.RIGHTclick(counter);
     });
}).call(this);





(function() {
    /*==== 
    General Tab function 
    ====*/
    var tabs = $('ul.index li'),
        divisions = $('section.index .blocks'),
        overviewTAB = $('ul.ulist li'),
        viewDIVISION = $('.stats .details'),
        
        liveTAB = $('#live ul.menu li'),
        // liveDIV = $('#live'),
        statsTAB = $('.stats .inform li'),
        cataTAB = $('.game.list .upper-most li'),
        // cataDIV = $('#catalogue .game.list li'),

        refMenu = $('.referral.front menu ul li'),
        // refBox = $(''),

        actionList = $('.payments .actions ul label'),
        effectBox = $('.payments .effect .box-d'),

         walletList = $('.payments ul.wallet li'),
        walletBox = $('.payments .effect .wallet-box'),

         // tradeList = $('.payments .box-d ul.currency li'),
         // tradeBox = $('.payments .exchange-box .trade'),

         // wrapBoxes = $('.payments .effect .right'),

        tabObject = {
        tabFunc(tabs, divisions) {
            let $this = this;

            // function uncheckall() {
               // actionList.each(function(index, obj) {
               //   $(obj).find('input').addClass('unchecked');
               //   console.log(obj);
               // })
            // }

            tabs.each(function(tabNo, elem) {
                $(elem).click((e)=> {
                    // console.log(actionList);
                    
                    if($(this).hasClass('hide-others')) {
                        effectBox.removeClass('show');
                        
                    } 
                    else {
                        effectBox.removeClass('hide');
                        walletBox.removeClass('show');
                    }

                    $(tabs).removeClass('active');
                    $(this).addClass('active');
                    $this.division(tabNo, divisions);

                });

            })
        },
        division(tabNo, divisions) {
            $(divisions).each(function(index, elem) {
                $(elem).removeClass('show');
                if(tabNo == index) {
                    $(elem).addClass('show');
                }
            });
        }
    };
    tabObject.tabFunc(tabs, divisions);
    tabObject.tabFunc(overviewTAB, viewDIVISION);
    tabObject.tabFunc(liveTAB, liveDIV = null);
    tabObject.tabFunc(statsTAB, statsDIV = null);
    tabObject.tabFunc(cataTAB, cataDIV = null);
    tabObject.tabFunc(refMenu, refBox = null);
    tabObject.tabFunc(actionList, effectBox);
    // tabObject.tabFunc(tradeList, tradeBox);
    tabObject.tabFunc(walletList, walletBox);

    // actionList.find('input').attr('checked', false);


}).call(this);




(function() {
    /*====
        General Modal Function.
    ====*/
    var modal = $('.modal.target'),
        showBTN = $('.show.btn');

    function modalFunc(showBtn, modal) {
        showBTN.click(function(e) {
            // console.log($(this).data('gameid'));

            if(!modal.hasClass('show')) {
                modal.addClass('show');
                $('body').addClass('noscroll');

                $(window).click(function(e) {
                    if($(e.target).hasClass('close')) {
                        modal.removeClass('show');
                        $('body').removeClass('noscroll');
                    }
                })
            } 
        });
    }
    modalFunc(showBTN, modal);

}).call(this);





(function() {
    /*====
     show Selected account Type. ==== */

    var accOptions = $('.account.payments .up .wallets'),
        methods = $('.payments .deposit-wrap ul.methlist li'),
        allPayBox = $('.account.payments .deposit-wrap .middle'),
        collector = $('.account.payments .deposit-wrap .methods'),
        depowrapUp = $('.account.payments .deposit-wrap .up'),
        showMeths = $('.account.payments .act-title .show-m'),

        payMethodObj = {
            selectM (methodList, collector) {
                var $this = this;


                

                methodList.each(function(index, obj) {
                    $(this).click(function() {
                        $this.showPayBox($this, index);
                    });
                });

            }, 
            showPayBox($this, num) {
                allPayBox.each(function(index, elem) {
                    if(num === index) {
                        $(collector).replaceWith(elem);
                        $(elem).addClass('show');
                    }
                    // $this.returnMethods(elem);
                })
            },
            returnMethods(elem) {
                accOptions.on('change', function() {
                    let accType= $(this).find(':selected').val();
                    // $(elem).replaceWith(collector);
                    // switch(accType) {
                    //     case '':
                    //     console.log(accType);
                    //     break;
                    // }
                });

                // showallMeths.click(function() {
                //     $(depowrapUp).replaceWith(collector);
                // });
            }



        }
        payMethodObj.selectM(methods, collector);
        

       
  
      
    
}).call(this);






(function() {
/*==== 
    General drop down box.
====*/

var targetBtn = $('.account .balance'),
    boxSheet = $('.account .sheet'),
    langBtn = $('.translate .change, .active.nav ul li.translate '),
    langList = $('.translate .list, .active.nav ul li .list.target'),
    chatBtn = $('.account .accept a.chat'),
    chatBox = $('.chat.pop.out'),
    tClose = $('.chat.pop.out .close'),
    // hideBalance = $('.balance .hide-acc'),
    liveBtn = $('.active.nav ul li.live.target'),
    liveBox = $('.active.nav ul.tray'),
    addTarget = [targetBtn, boxSheet, chatBox],
    addSheetBox = [boxSheet],
    addChatBox = [chatBox],

    boxObject = {

        showBox(clickBtn, shownBox, boxName) {
            var $Obj = this;

            $(clickBtn).on('click', function(e) {

                console.log($(this));
                
                $(clickBtn).removeClass('active');
                (!$(shownBox).hasClass('show') || 
                    $(e.target).hasClass(boxName))?
                        (function() { 
                            $(shownBox).addClass('show');
                            $(clickBtn).addClass('active')}
                        ()) :
                         (function() {
                            $(clickBtn).removeClass('active');
                            $(shownBox).removeClass('show');
                         }());

                        $Obj.windowTarget(clickBtn, shownBox, boxName);
            });
        },
        windowTarget(clickBtn, shownBox, boxName) {
             $(window).click(function(ev) {
                if(!$(ev.target).hasClass('target') && 
                    (boxName === 'sheetbox')) {
                    $(shownBox).removeClass('show');
                    $(clickBtn).removeClass('active')
                }
                else if($(ev.target).hasClass('end') && 
                    (boxName === 'chatbox')) {
                    $(shownBox).removeClass('show');
                }
                else if(!$(ev.target).hasClass('target') &&
                    (boxName === 'langbox')) {
                    $(shownBox).removeClass('show');
                } 
                else if(!$(ev.target).hasClass('target') &&
                    (boxName === 'livebox')) {
                    $(shownBox).removeClass('show');
                }
            });
        }
    };

    (function(arguments) {
        for(var index in arguments) {
            switch(index) {
                case '0':
                    $(arguments[index]).each((num, obj)=> {
                        $(obj).find('*').addClass('target');
                    });
                break;
                case '1':
                    $(arguments[index]).each((num, obj)=> {
                        $(obj).find('*').addClass('sheetbox');
                    });
                break;
                case '2':
                    $(arguments[index]).each((num, obj)=> {
                        $(obj).find('*').addClass('langbox');
                    });
                break; 
                // case '3':
                //     $(arguments[index]).each((num, obj)=> {
                //         $(obj).find('*').addClass('chatbox');
                //     });
                // break;                    
            }
        }
    }([addTarget, addSheetBox, addChatBox]));    


    boxObject.showBox(targetBtn, boxSheet, 'sheetbox');
    boxObject.showBox(chatBtn, chatBox, 'chatbox');
    boxObject.showBox(langBtn, langList, 'langbox');
    boxObject.showBox(liveBtn, liveBox, 'livebox');


    // console.log(hideBalance);

}).call(this);





(function() {
    /*==== 
        Tooltip General function.
    ====*/
    var element = $('aside.refresh'),
        cplayers = $('ul.player li'),
        infoBox = $('label.tool-tip');


        function toolTip(cplayers, infoBox) {

            cplayers.hover(
                ()=> {
                // $(this).data('info');
                infoBox.addClass('active');
                }, 
                ()=> infoBox.removeClass('active'));
        }

        toolTip(cplayers, infoBox);


}).call(this);




(function() {

    var inPlayObj = {

            direction: $('.ingame [class*="side"]'),
             timeElem: $('svg.circle .time'),
            totalTime: 300,
              seconds: 60,
        circle_radius: 158,
              playImg: [
            'passport.jpg',
            'passport.jpg'
        ],
           alphaColor: [
            '255, 191, 0, 0.4',
            '255, 0, 255, 0.4',
            '54, 106, 106, 0.4',
            '204, 204, 255, 0.4',
            '222, 49, 99, 0.4',
            '255, 127, 80, 0.4',
            '255, 20, 147, 0.4',
            '50, 205, 50, 0.4',
            '0, 191, 255, 0.4',
            '188, 143, 143, 0.4'
        ],
              pcolors: [
                    '#ffbf00',
                    '#ff00ff',
                    '#368b8b',
                    '#ccccff',
                    '#de3163',
                    '#ff7f50',
                    '#ff1493',
                    '#32cd32',
                    '#800080',
                    '#00bfff',
                    '#bc8f8f',
                    '#45b39d',
                    '#dfff00',
                    '#40e0d0',
                    '#792b62'
        ],
                links: $('ul.player > li'),
    
                returnColor(playImg, alphaColor, elem, index) {
                    $(elem).css({
                    'border': '0.15em solid rgba(' + this.alphaColor[index] + ')',
                    'background': 'url("/games.com/resources/picture/'+ this.playImg[index] + '")',
                    'background-size': 'cover'
                    }).removeClass('pointer');
                },
                init() {

                    let $this = this;
                    this.links.each(function(index, elem) {
                        $(this).attr('data-index',index);
                        $this.returnColor($this.playImg, 
                            $this.alphaColor, elem, index);

                        var cordvalues = animateCircle($(this));
                        // console.log(cordvalues);
                        $(elem).hover(
                            function() {
                            $(this).css({
                            'border': '0.15em solid ' + 
                            $this.pcolors[index]
                            });
                            // .addClass('pointer');
                            }, 
                            function() {
                            $this.returnColor($this.playImg, 
                                $this.alphaColor, elem, 
                                index);
                            });
                    });
                    function animateCircle(links) {
                        var index = links.attr('data-index'),
                        radians = (2 * Math.PI * (index/
                            $this.links.length)).toFixed(5),
                        x = -(Math.sin(radians) * $this.circle_radius),
                        y = -(Math.cos(radians) * $this.circle_radius);
                        links.animate({
                            top: x + 'px',
                            left: y + 'px'
                        }, 500);
                        var cordinate = [x, y];
                        return cordinate;
                        // console.log(cordinate);
                    }

                    let timePara = setInterval(clockFunc, 1000);
                    function clockFunc() {
                        $this.totalTime-=1;
                        $this.seconds-=1;
                        let minutes = parseInt($this.totalTime/60),
                            clockvalue;
                        if($this.seconds < 0) {
                            $this.seconds = 60;
                        }
                        clockvalue = `${minutes}m:${$this.seconds}`;
                        $this.timeElem.text(clockvalue);

                          if(minutes == 0 && 
                            $this.seconds == 0) {
                            clearInterval(timePara);
                          }
                    };
                     
                   
                },
                leftRight() {
                    this.direction.click(function() {
                        if($(this).hasClass('prev')) {
                        console.log('Prev button clicked.');
                        } else {
                        console.log('Next button clicked.');
                        }
                    });
                }
    }
    inPlayObj.init();


}).call(this);






/*
(function() {


    var direction = $('.ingame [class*="side"]');

        direction.click(function() {

            if($(this).hasClass('prev')) {
                console.log('Prev button clicked.');
            } else {
                console.log('Next button clicked.');
            }
        });

}).call(this);
*/




(function() {

    var joinBtn = $('.ingame [class*="join"], ul.live li .join, #live .slide .close'),
        slideBox = $('#live .slide'),
        joinChallenge = {
           /* xxxx: $('').data('gameId'),
            yyyy: $('').data('genre'),
            gameData */
            slideOut() {
                slideBox.addClass('out');
            },
            showBox(joinBtn, slideBox) {
                var $this = this;
                joinBtn.click(function(e) {
                    if($(e.currentTarget).hasClass('close')) {
                        slideBox.removeClass('out');
                    } 
                    else {
                        $this.slideOut();
                    }
                    // if(gameData !== null || gameData !== '') {
                    //     slideBox.addClass('out');
                    // }
                });
            },


            // function slideOutOnload(joinChallenge) {
            // setTimeout(function(joinChallenge) {
            //     joinChallenge.slideOut();
            //     }, 300);
            // }


            // console.log('Inside php file..');
            // var gameId = 17;
            // if(gameId !== '' || gameId !== null) {
            // // slideOutOnload(joinChallenge);
            // alert('Yes sldie.')
            // } else {
            // // slideOutOnload(joinChallenge);
            // alert('No sldie.')
            // }


        };
        joinChallenge.showBox(joinBtn, slideBox);
        // console.log('Inside JS file..');
}());





(function(){
    
        // ...Deposit page and Account page....
    
    var depositForm = $('form.deposit'),
        methods = $('form.deposit label.select'),
        activeBox = $('.account.deposit .details'),

        question = $('.payments .encompass ul.ques li'),
        activeExp = $('.payments .encompass ul.ques .content');

        depositForm.on('submit', function(e) {
            e.preventDefault();
        });


    function accordion(accoBtn, activeBox) {

        accoBtn.click(function(e) {
            let $this = $(this),
                block = $this.next(activeBox);
                block.find('input').val('');
                block.addClass('show');
                $this.addClass('active');

                accoBtn.not($this).each((index, obj)=> {
                    $(obj).removeClass('active');
                });

                activeBox.not(block).each((index, obj)=> {
                    $(obj).removeClass('show');
                });

                if($this.hasClass('others')) {
                    $this.addClass('hide');
                } 
        });
    }
    accordion(methods, activeBox);
    accordion(question, activeExp);

}());




// var textarea = $('.fifth textarea'),
//  inputTexta = $('textarea.fifth').val(),
//  textLength = inputTexta.trim().length;


/*
let span = $('.fifth span.char');
    span.text(0);

$('.fifth textarea').on('keyup', function() {
        var $this = $(this);
        value = $this.val().trim().length;

        // console.log(value);

        // if($this.val().trim().length >= 201) {
        //     $this.val($this.val().slice(0, 201));
        //     return false;
        // } else {
        //     span.text(value);
        // }
        
        
});
*/



// if ($('html').is('.m320, .m768')) { ... }


/*
$('#create .player input.number').keypress(function() {
    alert('keypress');

    $this = $(this);
    return $this.val().length < 20;
    ($this.val().length >= 20)? (()=>{ 
    $this.val($this.val().slice(0,20));
    })() : console.log('');
});
*/




/*
var converted = Object.keys(objx).map(function(key, index) {
    // console.log(key);
    return [key, objx[key]];
    // return [index, objx[key]];
});

converted.forEach(function(converted) {
    // console.log(converted);
});
*/




   

/*



(function() {

    var canvas = document.getElementById("constarc"),
	contextw = canvas.getContext("2d"),
	x = canvas.width / 2,
	y = canvas.height / 2,
	radius = 75,
	startAngle = 0.5 * Math.PI,
	endAngle = 2 * Math.PI,
	counterClockwise = false;

	contextw.beginPath();
	contextw.arc(x, y, radius, startAngle, endAngle, counterClockwise);
	contextw.lineWidth = 5;
	contextw.strokeStyle = "red";
	contextw.stroke();

}());



*/












var ctx = document.getElementById('statistics').getContext('2d'),
	al = 0,
	start = 4.72,
	cw = ctx.canvas.width,
	ch = ctx.canvas.height,
	diff;

function progressSim() {
	diff = ((al / 100) * Math.PI * 2 * 10).toFixed(2);
	ctx.clearRect(0, 0, cw, ch);
	ctx.lineWidth = 5;
	ctx.fillStyle = '#4285f4';
	ctx.strokeStyle = "#4285f4";
	ctx.textAlign = "center";
	ctx.font = "2em monospace";
	ctx.fillText(al + '%', cw * .5, ch * .52 + 5, cw + 12);
	ctx.beginPath();
	ctx.arc(90, 90, 75, start, diff/10 + start, false);
	ctx.stroke();
	if(al >= 100){
		clearTimeout(sim);
	}
	al++;
}

var sim = setInterval(progressSim, 30);







// $('select[name=year]').on('change', function(){
//     checkTotalDay();
// });
// $('select[name=month]').on('change', function(){
//     checkTotalDay();
// });

// function checkTotalDay() {
//     var year = $('select[name=year]').val();
//     var month = $('select[name=month]').val();
//     var totalDate = 31;
//     if(year !== '' && month !== '') {
//         totalDate = new Date(year, month, 0).getDate();
//     }
//     $('select[name=date]').empty();
//     for(var i = 1; i <= totalDate; i++) {
//        $('select[name=date]').append("<option value='"+i+"'>"+i+"</option>");
//     }
// }







/*
jquery-circle-progress - jQuery Plugin to draw animated circular progress bars

URL: https://kottenator.github.io/jquery-circle-progress/
Author: Rostyslav Bryzgunov <kottenator@gmail.com>
Version: 1.1.3
License: MIT
*/ 
(function($) {
    function CircleProgress(config) {
        this.init(config);
    }

    CircleProgress.prototype = {
        //----------------------------------------------- public options -----------------------------------------------
        /**
         * This is the only required option. It should be from 0.0 to 1.0
         * @type {number}
         */
        value: 0.0,

        /**
         * Size of the circle / canvas in pixels
         * @type {number}
         */
        size: 100.0,

        /**
         * Initial angle for 0.0 value in radians
         * @type {number}
         */
        startAngle: -Math.PI,

        /**
         * Width of the arc. By default it's auto-calculated as 1/14 of size, but you may set it explicitly in pixels
         * @type {number|string}
         */
        thickness: 'auto',

        /**
         * Fill of the arc. You may set it to:
         *   - solid color:
         *     - { color: '#3aeabb' }
         *     - { color: 'rgba(255, 255, 255, .3)' }
         *   - linear gradient (left to right):
         *     - { gradient: ['#3aeabb', '#fdd250'], gradientAngle: Math.PI / 4 }
         *     - { gradient: ['red', 'green', 'blue'], gradientDirection: [x0, y0, x1, y1] }
         *   - image:
         *     - { image: 'https://i.imgur.com/pT0i89v.png' }
         *     - { image: imageObject }
         *     - { color: 'lime', image: 'https://i.imgur.com/pT0i89v.png' } - color displayed until the image is loaded
         */
        fill: {
            gradient: ['#3aeabb', '#f00']
        },

        /**
         * Color of the "empty" arc. Only a color fill supported by now
         * @type {string}
         */
        emptyFill: 'rgba(0, 0, 0, .0)',

        /**
         * Animation config (see jQuery animations: https://api.jquery.com/animate/)
         */
        animation: {
            duration: 1200,
            easing: 'circleProgressEasing'
        },

        /**
         * Default animation starts at 0.0 and ends at specified `value`. Let's call this direct animation.
         * If you want to make reversed animation then you should set `animationStartValue` to 1.0.
         * Also you may specify any other value from 0.0 to 1.0
         * @type {number}
         */
        animationStartValue: 0.0,

        /**
         * Reverse animation and arc draw
         * @type {boolean}
         */
        reverse: false,

        /**
         * Arc line cap ('butt', 'round' or 'square')
         * Read more: https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D.lineCap
         * @type {string}
         */
        lineCap: 'round',

        //-------------------------------------- protected properties and methods --------------------------------------
        /**
         * @protected
         */
        constructor: CircleProgress,

        /**
         * Container element. Should be passed into constructor config
         * @protected
         * @type {jQuery}
         */
        el: null,

        /**
         * Canvas element. Automatically generated and prepended to the {@link CircleProgress.el container}
         * @protected
         * @type {HTMLCanvasElement}
         */
        canvas: null,

        /**
         * 2D-context of the {@link CircleProgress.canvas canvas}
         * @protected
         * @type {CanvasRenderingContext2D}
         */
        ctx: null,

        /**
         * Radius of the outer circle. Automatically calculated as {@link CircleProgress.size} / 2
         * @protected
         * @type {number}
         */
        radius: 0.0,

        /**
         * Fill of the main arc. Automatically calculated, depending on {@link CircleProgress.fill} option
         * @protected
         * @type {string|CanvasGradient|CanvasPattern}
         */
        arcFill: null,

        /**
         * Last rendered frame value
         * @protected
         * @type {number}
         */
        lastFrameValue: 0.0,

        /**
         * Init/re-init the widget
         * @param {object} config - Config
         */
        init: function(config) {
            $.extend(this, config);
            this.radius = this.size / 2;
            this.initWidget();
            this.initFill();
            this.draw();
        },

        /**
         * @protected
         */
        initWidget: function() {
            var canvas = this.canvas = this.canvas || $('<canvas>').prependTo(this.el)[0];
            canvas.width = this.size;
            canvas.height = this.size;
            this.ctx = canvas.getContext('2d');
        },

        /**
         * This method sets {@link CircleProgress.arcFill}
         * It could do this async (on image load)
         * @protected
         */
        initFill: function() {
            var self = this,
                fill = this.fill,
                ctx = this.ctx,
                size = this.size;

            if (!fill)
                throw Error("The fill is not specified!");

            if (fill.color)
                this.arcFill = fill.color;

            if (fill.gradient) {
                var gr = fill.gradient;

                if (gr.length == 1) {
                    this.arcFill = gr[0];
                } else if (gr.length > 1) {
                    var ga = fill.gradientAngle || 0, // gradient direction angle; 0 by default
                        gd = fill.gradientDirection || [
                            size / 2 * (1 - Math.cos(ga)), // x0
                            size / 2 * (1 + Math.sin(ga)), // y0
                            size / 2 * (1 + Math.cos(ga)), // x1
                            size / 2 * (1 - Math.sin(ga))  // y1
                        ];

                    var lg = ctx.createLinearGradient.apply(ctx, gd);

                    for (var i = 0; i < gr.length; i++) {
                        var color = gr[i],
                            pos = i / (gr.length - 1);

                        if ($.isArray(color)) {
                            pos = color[1];
                            color = color[0];
                        }

                        lg.addColorStop(pos, color);
                    }

                    this.arcFill = lg;
                }
            }

            if (fill.image) {
                var img;

                if (fill.image instanceof Image) {
                    img = fill.image;
                } else {
                    img = new Image();
                    img.src = fill.image;
                }

                if (img.complete)
                    setImageFill();
                else
                    img.onload = setImageFill;
            }

            function setImageFill() {
                var bg = $('<canvas>')[0];
                bg.width = self.size;
                bg.height = self.size;
                bg.getContext('2d').drawImage(img, 0, 0, size, size);
                self.arcFill = self.ctx.createPattern(bg, 'no-repeat');
                self.drawFrame(self.lastFrameValue);
            }
        },

        draw: function() {
            if (this.animation)
                this.drawAnimated(this.value);
            else
                this.drawFrame(this.value);
        },

        /**
         * @protected
         * @param {number} v - Frame value
         */
        drawFrame: function(v) {
            this.lastFrameValue = v;
            this.ctx.clearRect(0, 0, this.size, this.size);
            this.drawEmptyArc(v);
            this.drawArc(v);
        },

        /**
         * @protected
         * @param {number} v - Frame value
         */
        drawArc: function(v) {
            var ctx = this.ctx,
                r = this.radius,
                t = this.getThickness(),
                a = this.startAngle;

            ctx.save();
            ctx.beginPath();

            if (!this.reverse) {
                ctx.arc(r, r, r - t / 2, a, a + Math.PI * 2 * v);
            } else {
                ctx.arc(r, r, r - t / 2, a - Math.PI * 2 * v, a);
            }

            ctx.lineWidth = t;
            ctx.lineCap = this.lineCap;
            ctx.strokeStyle = this.arcFill;
            ctx.stroke();
            ctx.restore();
        },

        /**
         * @protected
         * @param {number} v - Frame value
         */
        drawEmptyArc: function(v) {
            var ctx = this.ctx,
                r = this.radius,
                t = this.getThickness(),
                a = this.startAngle;

            if (v < 1) {
                ctx.save();
                ctx.beginPath();

                if (v <= 0) {
                    ctx.arc(r, r, r - t / 2, 0, Math.PI * 2);
                } else {
                    if (!this.reverse) {
                        ctx.arc(r, r, r - t / 2, a + Math.PI * 2 * v, a);
                    } else {
                        ctx.arc(r, r, r - t / 2, a, a - Math.PI * 2 * v);
                    }
                }

                ctx.lineWidth = t;
                ctx.strokeStyle = this.emptyFill;
                ctx.stroke();
                ctx.restore();
            }
        },

        /**
         * @protected
         * @param {number} v - Value
         */
        drawAnimated: function(v) {
            var self = this,
                el = this.el,
                canvas = $(this.canvas);

            // stop previous animation before new "start" event is triggered
            canvas.stop(true, false);
            el.trigger('circle-animation-start');

            canvas
                .css({ animationProgress: 0 })
                .animate({ animationProgress: 1 }, $.extend({}, this.animation, {
                    step: function (animationProgress) {
                        var stepValue = self.animationStartValue * (1 - animationProgress) + v * animationProgress;
                        self.drawFrame(stepValue);
                        el.trigger('circle-animation-progress', [animationProgress, stepValue]);
                    }
                }))
                .promise()
                .always(function() {
                    // trigger on both successful & failure animation end
                    el.trigger('circle-animation-end');
                });
        },

        /**
         * @protected
         * @returns {number}
         */
        getThickness: function() {
            return $.isNumeric(this.thickness) ? this.thickness : this.size / 14;
        },

        getValue: function() {
            return this.value;
        },

        setValue: function(newValue) {
            if (this.animation)
                this.animationStartValue = this.lastFrameValue;
            this.value = newValue;
            this.draw();
        }
    };

    //-------------------------------------------- Initiating jQuery plugin --------------------------------------------
    $.circleProgress = {
        // Default options (you may override them)
        defaults: CircleProgress.prototype
    };

    // ease-in-out-cubic
    $.easing.circleProgressEasing = function(x, t, b, c, d) {
        if ((t /= d / 2) < 1)
            return c / 2 * t * t * t + b;
        return c / 2 * ((t -= 2) * t * t + 2) + b;
    };

    /**
     * Draw animated circular progress bar.
     *
     * Appends <canvas> to the element or updates already appended one.
     *
     * If animated, throws 3 events:
     *
     *   - circle-animation-start(jqEvent)
     *   - circle-animation-progress(jqEvent, animationProgress, stepValue) - multiple event;
     *                                                                        animationProgress: from 0.0 to 1.0;
     *                                                                        stepValue: from 0.0 to value
     *   - circle-animation-end(jqEvent)
     *
     * @param configOrCommand - Config object or command name
     *     Example: { value: 0.75, size: 50, animation: false };
     *     you may set any public property (see above);
     *     `animation` may be set to false;
     *     you may use .circleProgress('widget') to get the canvas
     *     you may use .circleProgress('value', newValue) to dynamically update the value
     *
     * @param commandArgument - Some commands (like 'value') may require an argument
     */
    $.fn.circleProgress = function(configOrCommand, commandArgument) {
        var dataName = 'circle-progress',
            firstInstance = this.data(dataName);

        if (configOrCommand == 'widget') {
            if (!firstInstance)
                throw Error('Calling "widget" method on not initialized instance is forbidden');
            return firstInstance.canvas;
        }

        if (configOrCommand == 'value') {
            if (!firstInstance)
                throw Error('Calling "value" method on not initialized instance is forbidden');
            if (typeof commandArgument == 'undefined') {
                return firstInstance.getValue();
            } else {
                var newValue = arguments[1];
                return this.each(function() {
                    $(this).data(dataName).setValue(newValue);
                });
            }
        }

        return this.each(function() {
            var el = $(this),
                instance = el.data(dataName),
                config = $.isPlainObject(configOrCommand) ? configOrCommand : {};

            if (instance) {
                instance.init(config);
            } else {
                var initialConfig = $.extend({}, el.data());
                if (typeof initialConfig.fill == 'string')
                    initialConfig.fill = JSON.parse(initialConfig.fill);
                if (typeof initialConfig.animation == 'string')
                    initialConfig.animation = JSON.parse(initialConfig.animation);
                config = $.extend(initialConfig, config);
                config.el = el;
                instance = new CircleProgress(config);
                el.data(dataName, instance);
            }
        });
    };
})(jQuery);
;(function() {
    var proto = $.circleProgress.defaults,
        originalDrawEmptyArc = proto.drawEmptyArc;
    
    proto.emptyThickness = 5; // just a default value; 
                              // you may override it on init
    
    // overriding original method
    proto.drawEmptyArc = function(v) {
        var oldGetThickness = this.getThickness, 
            oldThickness = this.getThickness(),
            emptyThickness = this.emptyThickness || _oldThickness.call(this),
            oldRadius = this.radius,
            delta = (oldThickness - emptyThickness) / 2;

        this.getThickness = function() {
            return emptyThickness;
        };
        
        this.radius = oldRadius - delta;
        this.ctx.save();
        this.ctx.translate(delta, delta);
        
        originalDrawEmptyArc.call(this, v);
        
        this.ctx.restore();
        this.getThickness = oldGetThickness;
        this.radius = oldRadius;
    };
})();


/*
 * Example 3:
 *   - very custom gradient
 *   - listening to `circle-animation-progress` event and display the dynamic change of the value: from 0 to 0.8
 */


var day1 = 10; //Прототипирование
var day2 = 6; //Дизайн
var day3 = 10; //Верстка и программирование
var day4 = 6; //Тестирование
var total = day1+day2+day3+day4

$('.circle1').circleProgress({
    value: day1/total - 0.02,
    size:196,
    thickness: 5,
    startAngle:0 + (Math.PI * 2),
    fill: { color: "rgb(255, 188, 58)" },
    emptyFill: "rgba(232, 232, 232, 0)"
}).on('circle-animation-end	', function(){
  
});
setTimeout(function(){
  $('.circle2').circleProgress({
      value: day2/total - 0.02, 
      size:196,
      thickness: 5, 
      startAngle:0 + (Math.PI * 2) * (day1/total),
      fill: { color: "rgb(53, 138, 227)" },
      emptyFill: "rgba(232, 232, 232, 0)"
  });
}, 0) 

setTimeout(function(){
$('.circle3').circleProgress({
    value: day3/total - 0.02, 
    size:196,
    thickness: 5,
    startAngle:0 + (Math.PI * 2) * (day1/total + day2/total), 
    fill: { color: "rgb(238, 48, 80)" },
    emptyFill: "rgba(232, 232, 232, 0)"
});
}, 0) 

setTimeout(function(){
$('.circle4').circleProgress({
    value: day4/total - 0.02, 
    size:196,
    thickness: 5,
    startAngle:0 + (Math.PI * 2) * (day1/total + day2/total + day3/total), //посчитать
    fill: { color: "rgb(205, 205, 205)" },
    emptyFill: "rgba(232, 232, 232, 0)" 
}).on('circle-animation-end	', function(){
  $(".chart-wrap .total span").text(total);
  $(".chart-wrap .total").fadeIn(300);
});
}, 0)  





});

