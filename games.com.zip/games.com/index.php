<?php require 'header.php'; ?>



<header class="header index page">


    <div class="head-wrapper">
        <div class="upper">
          <div class="logo">
            
            <div>P4PGames</div>
            
            <div class="methods">
              <div class="deposit">

                <i class="far fa-credit-card"></i>

                &nbsp; Deposit 

              </div>

              <ul class="hover-display"> 
                
                <a href="https://google.com">
                  <li>Mastercard 
                    <div class="mastercard"></div> 
                    <br /><span>(Min $10, Max $5,000)</span>
                  </li>
                 </a>
                
                <li>Visacard
                  <div class="visacard"></div> 
                  <br /><span>(Min $10, Max $5,000)</span>
                </li>
                
                <li>Paypal
                  <div class="paypal"></div> 
                  <br /><span>(Min $10, Max $5,000)</span></li>
                </li>
                
                <li>Stripe
                  <div class="stripe"></div> 
                  <br /><span>(Min $10, Max $5,000)</span></li>
                </li>

                <li>Bitcoin
                  <div class="bitcoin"></div> 
                  <br /><span>(Min ฿0.00030, Max ฿0.15000)</span></li>
                </li>
              </ul>

            </div>


          </div>

          <div class="form-wrapper">
            <form class="login" autocomplete="off" novalidate="novalidate" method="post">
              <fieldset>
                  <ul>
                    <li class="download">Download 
                      <div class="barcode hover-display">
                          <div><img src="">Barcode</div>
                          <div>Scan to Download App IOS & Android</div>
                          <div><button>More Download Options</button></div>
                      </div>
                    </li>

                    <li>
                      <input type="text" maxlength="100" name="email" autocomplete="off" placeholder="Email/ Phone">
                    </li>
                    <li>
                      <input type="text" maxlength="100" name="password" autocomplete="off" placeholder="Password">
                    </li>
                    <li>
                       <button type="submit">Login</button>
                    </li>
                  </ul>
              </fieldset>
            </form>

            <div class="register">

              <a href="#">Forgot account?</a>
              <a href="register.php" target="_blank">Register 
                <i class="far fa-id-badge"></i>
              </a>

       
            </div>

            <div class="secured preview">
              <!-- <i class="far fa-times-circle close"></i> -->

              <label class="instruct">Please check that you are visiting the correct Link </label>

                <label class="link">
                  <span class="green">
                    <span class="lock"></span> &nbsp;https://</span>.p4pgames.com
                </label>
            </div>



          </div>
        </div>
  

<div class="logo explain"> 

  <div class="home index image-wrapper">



<!-- data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII= -->


  <ul class="images">
    <li>
      <img src="resources/picture/home-1.png">
    </li>
  </ul>
  

  <label class="slide dot"></label>


  <div class="digital">
        <label>Total Stake <br /> 
            <span>87,156 USD</span>
        </label>

        <label class="left side dir">
            <i class="fas fa-caret-left"></i>
        </label>


        <label class="right side dir">
            <i class="fas fa-caret-right"></i>
        </label>

        <label>
          Total Challenge 
          <br /> <span>2,107</span>
        </label>
  </div>

</div>

    





  <div class="play-now">
      
      <div class="discription">
        <div class="title">P4P Games</div>
         <div class="small">
         
         Play Crypto games with other players around the world  and earn crypto currencies.

        </div>
      </div>
     
      <div>
         
          <div class="balance">
<!-- 
             Personal Deposit Address <br />
              Wager .... Balance. -->
              <div class="data"> Wager </div>
              <div class="data"> Balance </div>
          </div>

          <div class="play-option">
            <ul>
              <li>10%</li>
              <li>25%</li>
              <li>50%</li>
              <li>Max</li>
            </ul>

            <ul>
              <li>0.001</li>
              <li>0.01</li>
              <li>0.1</li>
              <li>Reset</li>
            </ul>
          </div>
      </div>

      <div class="button"><button>Play Now</button></div>
      <!-- <div>adsdsdsd</div> -->
  </div>

        </div>
    </div>

</header>


<section class="transparent">
   <div class="inner">
   </div>
</section>



<section class="section index">

<ul class="index">
   <li class="active">Recent Play</li>
   <li>Leaders Board</li>
   <li>Awards</li>
</ul>


<div class="blocks show"> 

<table class="recent play">
   <thead>
       <th>S/N</th>
       <th>Username</th>
       <th>Game Genre</th>
       <th>Stake</th>
       <th>Result </th>
       <th>Profit/Loss</th>
       <th>Player Rank</th>
       <th>Date & Time</th>
   </thead>

<tbody>
<!-- 
฿ 
£
€
Ξ ♢
<i class="fab fa-ethereum"></i> 

Beginner, Graduate, Expert, Master, Grand Master and Legend.
-->

<tr>
 <td>1</td>
 <td>Ande_rson2</td>
 <td>Checkers</td>
 <td>0.04136 BTC</td>
 <td class="loss">Loss</td>
 <td class="receipt minus">0.0480150 BTC</td>
 <td>Beginner</td>
 <td>04-12-2021 08:35 pm</td>
</tr>

<tr>
<td>2</td>
<td>Ande_rson2</td>
<td>Lucky Dice</td>
<td>35.00 GBP</td>
<td class="win">Win</td>
<td class="receipt plus">75.00</td>
<td>656sd5sd</td>
<td>09-02-2021 05:35 pm</td>
</tr>

<tr>
<td>3</td>
<td>Ande_rson2</td>
<td>Solitaire</td>
<td>35.00 EUR</td>
<td class="win">Win</i></td>
<td class="receipt plus">€55.00</td>
<td>Graduate</td>
<td>09-03-2021 03:35 am</td>
</tr>

<tr>
<td>4</td>
<td>Ande_rson2</td>
<td>Joker Poker</td>
<td>27.00 GBP</td>
<td class="win">Win</i></td>
<td class="receipt plus">£55.00</td>
<td>Expert</td>
<td>24-12-2021 05:35 pm</td>
</tr>

<tr>
<td>5</td>
<td>Ande_rson2</td>
<td>Bowling</td>
<td>
 
9.00000 ETH</td>
<td class="win">Win</i></td>
<td class="receipt plus">$55.00</td>
<td>Master</td>
<td>18-04-2019 07:35 pm</td>
</tr>

<tr>
<td>6</td>
<td>Ande_rson2</td>
<td>Sudoku</td>
<td>€ 67.00</td>
<td class="win">Win</i></td>
<td class="receipt plus">€163.00</td>
<td>Grand Master</td>
<td>04-12-2021 03:35 am</td>
</tr>

<tr>
<td>7</td>
<td>Ande_rson2</td>
<td>Word puzzle</td>
<td>$ 35.00</td>
<td class="loss">Loss </td>
<td class="receipt minus">$58.00</td>
<td>Legend</td>
<td>14-06-2021 08:35 am</td>
</tr>


<tr>
<td>8</td>
<td>Ande_rson2</td>
<td>Scrabble</td>
<td>฿ 0.03713</td>
<td class="loss">Loss </td>
<td class="receipt minus">฿0.0471350</td>
<td>.... .....</td>
<td>03-08-2021 08:35 pm</td>
</tr>

<tr>
<td>9</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>€ 35.00</td>
<td class="win">Win</i></td>
<td class="receipt plus">€155.00</td>
<td>... ....</td>
<td>09-02-2021 05:35 pm</td>
</tr>

<tr>
<td>10</td>
<td>Ande_rson2</td>
<td>Lucky Dice</td>
<td>£ 35.00</td>
<td class="win">Win</i></td>
<td class="receipt plus">75.00</td>
<td>656sd5sd</td>
<td>09-02-2021 05:35 pm</td>
</tr>

<tr>
<td>11</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>$ 35.00</td>
<td class="loss">Loss </td>
<td class="receipt minus">$63.00</td>
<td>656sd5sd</td>
<td>21-11-2019 11:35 pm</td>
</tr>

<tr>
<td>12</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>$35.00</td>
<td class="win">Win</i></td>
<td class="receipt plus">$55.00</td>
<td>656sd5sd</td>
<td>26-09-2019 11:35 pm</td>
</tr>

<tr>
<td>13</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>$35.00</td>
<td class="loss">Loss </td>
<td class="receipt minus">$76.00</td>
<td>656sd5sd</td>
<td>18-05-2019 07:35 pm</td>
</tr>

<tr>
<td>14</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>$35.00</td>
<td class="loss">Loss </td>
<td class="receipt minus">$82.00</td>
<td>656sd5sd</td>
<td>08-01-2019 07:35 pm</td>
</tr>


<tr>
<td>15</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>฿0.03350</td>
<td class="loss">Loss </td>
<td class="receipt minus">฿0.0735021</td>
<td>656sd5sd</td>
<td>28-01-2019 07:35 pm</td>
</tr>

<tr>
<td>16</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>€35.00</td>
<td class="win">Win</i></td>
<td class="receipt plus">55.00</td>
<td>656sd5sd</td>
<td>17-06-2019 07:35 am</td>
</tr>

<tr>
<td>17</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>£35.00</td>
<td class="win">Win</i></td>
<td class="receipt plus">55.00</td>
<td>656sd5sd</td>
<td>12-04-2020 07:35 am</td>
</tr>

<tr>
<td>18,123,909</td>
<td>Ande_rson2</td>
<td>Checkers</td>
<td>฿0.0935021</td>
<td class="win">Win</i></td>
<td class="receipt plus">฿0.0984321</td>
<td>656sd5sd</td>
<td>12-06-2020 02:35 am</td>
</tr>
          
       </tbody>
   </table>
</div>

<div class="blocks">
  <table class="leaders board"> 
    <thead>
      <th>Player ID</th>
      <th>Game Genre</th>
      <th>Challenges</th>
      <th>Score</th>
      <th>Position</th>
      <th>Player Rank</th>
      <th>Total Loss</th>
      <th>Total Profit</th>
    </thead>

    <tbody class="leaders board">

     <script>
        for(var g = 1; g <= 18; g++) {
          $('tbody.leaders.board').append('<tr><td>E6DF61B8</td><td>222222222</td><td>222222222</td><td>dcsdxxxxx</td><td>'+ g +'</td><td>Beginner</td><td>scdcsdcsd</td><td>8,765 USD</td></tr>');
        }
      </script>

    </tbody>
  </table>
</div>


<div class="blocks">
  <table class="awards">
    <thead>
      <th>S/N</th>
      <th>Player ID</th>
      <th>Player Rank</th>
      <th>Score</th>

      <th>Prize</th>
      <th>Position</th>
      <th>Accepted</th>
      <th>Created</th>
    </thead>

    <tbody class="awards">

      <script>

        for(var g = 1; g <= 18; g++) {
          $('tbody.awards').append('<tr><td>'+ g +'</td><td>3333333333</td><td>3333333333</td><td>3333333333</td><td>3333333333</td><td>'+ g +'</td><td>3333333333</td><td>3333333333</td></tr>');
        }
      </script>

    </tbody>

  </table>
</div>







<div class="navigation">

       <div class="enteries"> 
          Showing <span>1 to 18</span> of 2,147 Enteries 
       </div>

       <button>
          <i class="fas fa-caret-left"></i>
          &nbsp;Previous
       </button>

       <label>-5</label>
       <label class="active">7</label>
       <label>5+</label>

       <button>
          Next &nbsp;
          <i class="fas fa-caret-right"></i>
       </button>

   </div>




<div class="guideline">
    
   <aside>
      
      <h3 class="notice">Select Game</h3>
      <p>
        &nbsp;Select from the numerous available.
        
        P2pgames is a realtime game with real human. Play with real human player (Not AI, or any Computer Program). 
        <br />
        <br />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod. tempor incididunt ut labore et dolore magna aliqua.
      </p>

      <a href="catalgue.php">
        <button class="action">Select</button>
      </a>

   </aside>

   <aside>
      <h3 class="notice">Create Challenge</h3> 

      <p>
        Where Everything is possible with Crypto Gaming.
        <br />
        <br />
        Earn the Alias award. This will give you the option to set an alias to be ranked on our global leaderboard. 
      </p>

      <a href="catalgue.php">
        <button class="action">Create</button>
      </a>

   </aside>

   <aside>

    <h3 class="notice">Accept Challenge</h3>
      
      <p>
        4p4games has thousands of free online games for all generation. Play action, racing, sports, and other fun games for free at 4p4games.
        <br />
        <br />
        Play, Win and Earn
      </p>

      <a href="challenge.php">
        <button class="action">Accept</button>
      </a>

   </aside>

</div> 



</section>


<?php require 'footer.php'; ?>