<?php require 'header.php'; ?>
<?php require 'main.php'; ?>



<section class="account body overview" id="live">

<div class="inner">

<div class="left menu">
		
		<?php include'search.php'; ?>

		<ul  class="menu">
			<li class="active">All Genres</li>
			<li>Arcademics</li>
			<li>Board games</li>
			<li>Lottery Draw</li>
			<li>Casino & Poker</li>
			<li>Trending Now</li>
			<li>New Release</li>
			<li>Most Popular</li>
			<li>Favourites</li>
		</ul>
</div>


<div class="live box">

<ul class="live">

	<script>
		for(var c = 1; c <= 38; c++) {
			// console.log($('ul.live'));
			$('#live ul.live').append('<li><div class="transp join"></div><div class="stats"><ul><li>Stake <span class="stake value">$45.17</span></li>				<li class="time value"><span class="led light active"></span><span class="value">30 mins : 12s</span></li>				<li>Prize <span class="prize value">$271.02</span></li><li class="players">Players <span class="value">6</span></li></ul></div><div class="game img"></div></li>');
		}
	</script>

</ul>

<aside class="slide">
	<label class="close">
		Close 
		<i class="fas fa-caret-right"></i>
	</label>

	
		<div class="lower">
			<form>
				Balance..., Stake, Prize, 
				<button>Go</button>
			</form>
		</div>
</aside>

</div>


<!-- <div class="led-green"></div> -->



<!-- Show games that are live, currently being played by other players.
<br />
Show player statistics.<br />
Player pictures.<br />
Prize to win.<br />


led light glowing beside time remaining.
<br />

In-Play.
<br />
Ended
<br />

Live

<br />

Spin Trigger
30 Times
<br />
Min Wager
300 in BTC
<br />
Contest Duration
5 hours
<br />
Estimated Prize
2500 BTC
<br /> -->



</div>

<footer class="mini footer bottom">
<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>
</footer>


</section>


<div id="transparent" class="overview"></div>
<script src="assets/script/script.js"></script>

<script>

   //  function slideOutOnload(joinChallenge) {
   //  	setTimeout(function(joinChallenge) {
			// joinChallenge.slideOut();
			// }, 300);
   //  }

	// $(document).ready(function() {

	// 	console.log('Inside php file..');

	// 	var gameId = 17;
	// 	if(gameId !== '' || gameId !== null) {
	// 		// slideOutOnload(joinChallenge);
	// 		alert('Yes sldie.')
	// 	} else {
	// 		// slideOutOnload(joinChallenge);
	// 		alert('No sldie.')
	// 	}
	// })
</script>



