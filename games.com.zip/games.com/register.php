<?php require 'header.php' ?>


<header class="register login head">
	<div class="inner">

		<a href="http://localhost:81/games.com/">
				<aside class="logo">
					P4PGames
				</aside>
		</a>

		<aside class="translation">

			

			
			<i class="fas fa-globe-europe"></i>&nbsp; English &nbsp; <i class="fas fa-caret-down"></i>

			<div class="languages">
				French, Chinese, Spain..e.t.c.
			</div>
			
		</aside>


	</div>
</header>

<section class="reg-wrapper">

<div class="register">
	<form method="post" autocomplete="off" novalidate="novalidate">
	
	<fieldset>
		<h3>Create a free account&ensp;|&ensp;Welcome to p4pgames</h3>
		<br />
		<label>Email Address</label>
			<input type="email" autocomplete="off" name="" value="" placeholder="Enter email" autofocus>

		<label>Password</label>
			<input type="password" autocomplete="off" name="" value="" placeholder="Enter password">

		<label>Challenge ID (Optional)</label>
		<input type="text" name="" value="" placeholder="Referral ID">

		<div class="notice">By Creating account, you agree to our 
			<a href="#">Policies</a>
		</div>	

		<br />
		<button type="submit">Create Account</button>

		<br />
		<br />

		<span class="notice question">Already registered?  
			<a href="login.php">Log In</a>
		</span>

	</fieldset>
	</form>
</div>


</section>





<footer class="mini bottom">
	<label>© 2014 - 2021 p4pgames.com. All rights reserved.</label>
</footer>

<script src="assets/script/script.js"></script>


